import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { auth } from "@/lib/auth"

export async function GET() {
  const session = await auth()
  if (!session || session.user?.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const users = await prisma.user.findMany({
    select: {
      id: true,
      name: true,
      phone: true,
      email: true,
      role: true,
      createdAt: true,
      _count: { select: { orders: true } },
    },
    orderBy: { createdAt: "desc" },
  })

  return NextResponse.json(users)
}

export async function PATCH(req: Request) {
  const session = await auth()
  if (!session || session.user?.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { id, role, name } = await req.json()
    if (!id) return NextResponse.json({ error: "ID required" }, { status: 400 })

    if (id === session.user.id) {
      return NextResponse.json({ error: "Cannot modify your own account" }, { status: 400 })
    }

    const data: Record<string, string> = {}
    if (role && ["user", "admin"].includes(role)) data.role = role
    if (name !== undefined) data.name = name

    const user = await prisma.user.update({ where: { id }, data })
    return NextResponse.json(user)
  } catch (err) {
    console.error("User update error:", err)
    return NextResponse.json({ error: "Failed to update user" }, { status: 500 })
  }
}
