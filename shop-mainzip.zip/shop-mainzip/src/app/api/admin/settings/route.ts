import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { auth } from "@/lib/auth"

async function ensureSettings() {
  let settings = await prisma.storeSettings.findUnique({ where: { id: "default" } })
  if (!settings) {
    settings = await prisma.storeSettings.create({ data: { id: "default" } })
  }
  return settings
}

export async function GET() {
  const session = await auth()
  if (!session || session.user?.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }
  const settings = await ensureSettings()
  // Mask secrets: return placeholder if set, empty if not
  return NextResponse.json({
    ...settings,
    razorpayKeySecret: settings.razorpayKeySecret ? "••••••••••••••••" : "",
    phonePeSaltKey: settings.phonePeSaltKey ? "••••••••••••••••" : "",
  })
}

export async function PUT(req: Request) {
  const session = await auth()
  if (!session || session.user?.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const data = await req.json()

    const allowed = [
      "storeName", "storeTagline", "storeLogo", "storePhone", "storeEmail",
      "storeAddress", "taxRate", "freeShippingThreshold", "currencyCode",
      "bannerText", "bannerColor", "bannerActive", "heroTitle", "heroSubtitle",
      "metaDescription",
      // Payment gateway
      "activeGateway", "razorpayKeyId", "phonePeMerchantId",
      "phonePeSaltIndex", "phonePeMode",
      // COD
      "codEnabled", "codFee",
    ]

    const filtered: Record<string, unknown> = {}
    for (const key of allowed) {
      if (key in data) filtered[key] = data[key]
    }

    // Only update secrets if user typed a new value (not the masked placeholder)
    if (data.razorpayKeySecret && !data.razorpayKeySecret.startsWith("••")) {
      filtered.razorpayKeySecret = data.razorpayKeySecret
    }
    if (data.phonePeSaltKey && !data.phonePeSaltKey.startsWith("••")) {
      filtered.phonePeSaltKey = data.phonePeSaltKey
    }

    await ensureSettings()
    const settings = await prisma.storeSettings.update({
      where: { id: "default" },
      data: filtered,
    })

    return NextResponse.json({
      ...settings,
      razorpayKeySecret: settings.razorpayKeySecret ? "••••••••••••••••" : "",
      phonePeSaltKey: settings.phonePeSaltKey ? "••••••••••••••••" : "",
    })
  } catch (err) {
    console.error("Settings update error:", err)
    return NextResponse.json({ error: "Failed to update settings" }, { status: 500 })
  }
}
