import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { auth } from "@/lib/auth"

export async function GET() {
  const session = await auth()
  if (!session || session.user?.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const [allOrders, allProducts, allUsers] = await Promise.all([
    prisma.order.findMany({
      include: {
        items: {
          include: { product: { include: { category: true } } },
        },
        user: { select: { id: true, name: true, phone: true, email: true } },
      },
      orderBy: { createdAt: "asc" },
    }),
    prisma.product.findMany({ include: { category: true } }),
    prisma.user.findMany({ select: { id: true, createdAt: true } }),
  ])

  const completedOrders = allOrders.filter((o) => o.status !== "cancelled")

  const revenueByDay: Record<string, number> = {}
  const ordersByDay: Record<string, number> = {}
  const revenueByMonth: Record<string, number> = {}
  const ordersByMonth: Record<string, number> = {}

  completedOrders.forEach((o) => {
    const date = o.createdAt.toISOString().slice(0, 10)
    const month = o.createdAt.toISOString().slice(0, 7)
    revenueByDay[date] = (revenueByDay[date] || 0) + o.total
    ordersByDay[date] = (ordersByDay[date] || 0) + 1
    revenueByMonth[month] = (revenueByMonth[month] || 0) + o.total
    ordersByMonth[month] = (ordersByMonth[month] || 0) + 1
  })

  const dailyRevenue = Object.entries(revenueByDay)
    .map(([date, revenue]) => ({ date, revenue: Math.round(revenue * 100) / 100, orders: ordersByDay[date] || 0 }))
    .sort((a, b) => a.date.localeCompare(b.date))
    .slice(-30)

  const monthlyRevenue = Object.entries(revenueByMonth)
    .map(([month, revenue]) => ({ month, revenue: Math.round(revenue * 100) / 100, orders: ordersByMonth[month] || 0 }))
    .sort((a, b) => a.month.localeCompare(b.month))
    .slice(-12)

  const productRevenue: Record<string, { name: string; revenue: number; units: number; category: string }> = {}
  completedOrders.forEach((o) => {
    o.items.forEach((item) => {
      const pid = item.productId
      if (!productRevenue[pid]) {
        productRevenue[pid] = {
          name: item.product.name,
          revenue: 0,
          units: 0,
          category: item.product.category?.name || "Uncategorized",
        }
      }
      productRevenue[pid].revenue += item.price * item.quantity
      productRevenue[pid].units += item.quantity
    })
  })

  const topProducts = Object.entries(productRevenue)
    .map(([id, data]) => ({ id, ...data, revenue: Math.round(data.revenue * 100) / 100 }))
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, 10)

  const categoryRevenue: Record<string, number> = {}
  completedOrders.forEach((o) => {
    o.items.forEach((item) => {
      const cat = item.product.category?.name || "Uncategorized"
      categoryRevenue[cat] = (categoryRevenue[cat] || 0) + item.price * item.quantity
    })
  })

  const revenueByCategory = Object.entries(categoryRevenue)
    .map(([category, revenue]) => ({ category, revenue: Math.round(revenue * 100) / 100 }))
    .sort((a, b) => b.revenue - a.revenue)

  const ordersByStatus: Record<string, number> = {}
  allOrders.forEach((o) => {
    ordersByStatus[o.status] = (ordersByStatus[o.status] || 0) + 1
  })
  const statusBreakdown = Object.entries(ordersByStatus).map(([status, count]) => ({ status, count }))

  const usersByDay: Record<string, number> = {}
  allUsers.forEach((u) => {
    const date = u.createdAt.toISOString().slice(0, 10)
    usersByDay[date] = (usersByDay[date] || 0) + 1
  })
  const userGrowth = Object.entries(usersByDay)
    .map(([date, count]) => ({ date, count }))
    .sort((a, b) => a.date.localeCompare(b.date))
    .slice(-30)

  const avgOrderValue =
    completedOrders.length > 0
      ? Math.round((completedOrders.reduce((s, o) => s + o.total, 0) / completedOrders.length) * 100) / 100
      : 0

  const totalRevenue = completedOrders.reduce((s, o) => s + o.total, 0)

  return NextResponse.json({
    summary: {
      totalRevenue: Math.round(totalRevenue * 100) / 100,
      totalOrders: allOrders.length,
      completedOrders: completedOrders.length,
      totalProducts: allProducts.length,
      totalUsers: allUsers.length,
      avgOrderValue,
    },
    dailyRevenue,
    monthlyRevenue,
    topProducts,
    revenueByCategory,
    statusBreakdown,
    userGrowth,
  })
}
