import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { auth } from "@/lib/auth"

export async function GET() {
  const session = await auth()
  if (!session || session.user?.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }
  const coupons = await prisma.coupon.findMany({ orderBy: { createdAt: "desc" } })
  return NextResponse.json(coupons)
}

export async function POST(req: Request) {
  const session = await auth()
  if (!session || session.user?.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }
  try {
    const data = await req.json()
    const code = data.code?.toString().trim().toUpperCase()
    if (!code) return NextResponse.json({ error: "Code is required" }, { status: 400 })
    if (!data.discount || isNaN(parseFloat(data.discount))) {
      return NextResponse.json({ error: "Valid discount is required" }, { status: 400 })
    }
    const existing = await prisma.coupon.findUnique({ where: { code } })
    if (existing) return NextResponse.json({ error: "Coupon code already exists" }, { status: 409 })

    const coupon = await prisma.coupon.create({
      data: {
        code,
        discount: parseFloat(data.discount),
        type: data.type === "fixed" ? "fixed" : "percent",
        minOrder: data.minOrder ? parseFloat(data.minOrder) : null,
        maxUses: data.maxUses ? parseInt(data.maxUses) : null,
        active: data.active !== false,
        expiresAt: data.expiresAt ? new Date(data.expiresAt) : null,
      },
    })
    return NextResponse.json(coupon)
  } catch (err) {
    console.error("Coupon create error:", err)
    return NextResponse.json({ error: "Failed to create coupon" }, { status: 500 })
  }
}

export async function PATCH(req: Request) {
  const session = await auth()
  if (!session || session.user?.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }
  try {
    const { id, active } = await req.json()
    if (!id) return NextResponse.json({ error: "ID required" }, { status: 400 })
    const coupon = await prisma.coupon.update({
      where: { id },
      data: { active: Boolean(active) },
    })
    return NextResponse.json(coupon)
  } catch (err) {
    console.error("Coupon update error:", err)
    return NextResponse.json({ error: "Failed to update coupon" }, { status: 500 })
  }
}

export async function DELETE(req: Request) {
  const session = await auth()
  if (!session || session.user?.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }
  try {
    const { id } = await req.json()
    if (!id) return NextResponse.json({ error: "ID required" }, { status: 400 })
    await prisma.coupon.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (err) {
    console.error("Coupon delete error:", err)
    return NextResponse.json({ error: "Failed to delete coupon" }, { status: 500 })
  }
}
