import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { auth } from "@/lib/auth"
import { slugify } from "@/lib/utils"

export async function GET() {
  const session = await auth()
  if (!session || session.user?.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }
  const categories = await prisma.category.findMany({
    include: { _count: { select: { products: true } } },
    orderBy: { name: "asc" },
  })
  return NextResponse.json(categories)
}

export async function POST(req: Request) {
  const session = await auth()
  if (!session || session.user?.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }
  try {
    const { name, image } = await req.json()
    if (!name?.trim()) {
      return NextResponse.json({ error: "Name is required" }, { status: 400 })
    }
    const slug = slugify(name.trim())
    const existing = await prisma.category.findFirst({
      where: { OR: [{ name: name.trim() }, { slug }] },
    })
    if (existing) {
      return NextResponse.json({ error: "Category already exists" }, { status: 409 })
    }
    const category = await prisma.category.create({
      data: { name: name.trim(), slug, image: image || "📦" },
    })
    return NextResponse.json(category)
  } catch (err) {
    console.error("Category create error:", err)
    return NextResponse.json({ error: "Failed to create category" }, { status: 500 })
  }
}

export async function PUT(req: Request) {
  const session = await auth()
  if (!session || session.user?.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }
  try {
    const { id, name, image } = await req.json()
    if (!id || !name?.trim()) {
      return NextResponse.json({ error: "ID and name required" }, { status: 400 })
    }
    const category = await prisma.category.update({
      where: { id },
      data: { name: name.trim(), image: image || "📦" },
    })
    return NextResponse.json(category)
  } catch (err) {
    console.error("Category update error:", err)
    return NextResponse.json({ error: "Failed to update category" }, { status: 500 })
  }
}

export async function DELETE(req: Request) {
  const session = await auth()
  if (!session || session.user?.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }
  try {
    const { id } = await req.json()
    if (!id) return NextResponse.json({ error: "ID required" }, { status: 400 })
    const count = await prisma.product.count({ where: { categoryId: id } })
    if (count > 0) {
      return NextResponse.json(
        { error: `Cannot delete: ${count} product(s) assigned to this category` },
        { status: 409 }
      )
    }
    await prisma.category.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (err) {
    console.error("Category delete error:", err)
    return NextResponse.json({ error: "Failed to delete category" }, { status: 500 })
  }
}
