import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { auth } from "@/lib/auth"

export async function GET() {
  const session = await auth()
  if (!session || session.user?.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }
  const subscribers = await prisma.newsletter.findMany({
    orderBy: { createdAt: "desc" },
  })
  return NextResponse.json(subscribers)
}
