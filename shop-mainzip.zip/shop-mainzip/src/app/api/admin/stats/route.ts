import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { auth } from "@/lib/auth"

export async function GET() {
  const session = await auth()
  if (!session || session.user?.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const [totalOrders, totalProducts, totalUsers, allOrders] = await Promise.all([
    prisma.order.count(),
    prisma.product.count(),
    prisma.user.count(),
    prisma.order.findMany({
      select: { total: true, createdAt: true, status: true },
      orderBy: { createdAt: "asc" },
    }),
  ])

  const completedOrders = allOrders.filter((o) => o.status !== "cancelled")
  const totalRevenue = completedOrders.reduce((sum, o) => sum + o.total, 0)

  const revenueByDay: Record<string, number> = {}
  completedOrders.forEach((o) => {
    const date = o.createdAt.toISOString().slice(0, 10)
    revenueByDay[date] = (revenueByDay[date] || 0) + o.total
  })

  const revenueChart = Object.entries(revenueByDay)
    .map(([date, revenue]) => ({ date, revenue: Math.round(revenue * 100) / 100 }))
    .sort((a, b) => a.date.localeCompare(b.date))

  const ordersByStatus: Record<string, number> = {}
  allOrders.forEach((o) => {
    ordersByStatus[o.status] = (ordersByStatus[o.status] || 0) + 1
  })

  const statusChart = Object.entries(ordersByStatus).map(([status, count]) => ({
    status,
    count,
  }))

  const now = new Date()
  const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)
  const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)

  const recentOrders = allOrders.filter((o) => new Date(o.createdAt) >= thirtyDaysAgo)
  const weekOrders = allOrders.filter((o) => new Date(o.createdAt) >= sevenDaysAgo)

  const monthRevenue = recentOrders
    .filter((o) => o.status !== "cancelled")
    .reduce((s, o) => s + o.total, 0)
  const weekRevenue = weekOrders
    .filter((o) => o.status !== "cancelled")
    .reduce((s, o) => s + o.total, 0)

  return NextResponse.json({
    totalRevenue: Math.round(totalRevenue * 100) / 100,
    totalOrders,
    totalProducts,
    totalUsers,
    revenueChart,
    statusChart,
    monthRevenue: Math.round(monthRevenue * 100) / 100,
    weekRevenue: Math.round(weekRevenue * 100) / 100,
    monthOrders: recentOrders.length,
    weekOrders: weekOrders.length,
  })
}
