"use client"

import { motion } from "framer-motion"
import { User, Package, Heart, LogOut, ArrowRight, Smartphone, MapPin, CheckCircle2, Clock, Truck, XCircle } from "lucide-react"
import Link from "next/link"
import { useSession, signOut } from "next-auth/react"
import { useState, useEffect } from "react"
import { formatPrice } from "@/lib/utils"

interface OrderItem {
  id: string
  quantity: number
  price: number
  product: { name: string; image: string; slug: string }
}

interface Order {
  id: string
  createdAt: string
  status: string
  total: number
  address: string | null
  paymentId: string | null
  paymentMethod: string | null
  couponCode: string | null
  couponDiscount: number | null
  items: OrderItem[]
}

const statusConfig: Record<string, { color: string; icon: React.ElementType; label: string }> = {
  pending: { color: "bg-muted text-muted-foreground", icon: Clock, label: "Pending" },
  processing: { color: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400", icon: Clock, label: "Processing" },
  shipped: { color: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400", icon: Truck, label: "Shipped" },
  delivered: { color: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400", icon: CheckCircle2, label: "Delivered" },
  cancelled: { color: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400", icon: XCircle, label: "Cancelled" },
}

export default function AccountPage() {
  const { data: session, status } = useSession()
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [tab, setTab] = useState<"profile" | "orders">("orders")
  const [expandedOrder, setExpandedOrder] = useState<string | null>(null)

  useEffect(() => {
    if (status === "authenticated") {
      fetch("/api/orders")
        .then((r) => r.json())
        .then((data) => {
          setOrders(Array.isArray(data) ? data : [])
          setLoading(false)
        })
        .catch(() => setLoading(false))
    }
  }, [status])

  if (status === "loading" || (status === "authenticated" && loading)) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-foreground border-t-transparent" />
      </div>
    )
  }

  if (status === "unauthenticated") {
    return (
      <div className="flex flex-col items-center py-20 text-center">
        <span className="text-5xl">🔒</span>
        <h1 className="mt-4 text-2xl font-bold">Sign in to view your account</h1>
        <Link href="/auth/signin" className="mt-6 rounded-lg bg-foreground px-6 py-2.5 text-sm font-medium text-background">
          Sign In
        </Link>
      </div>
    )
  }

  const tabClass = (active: boolean) =>
    `flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition-colors ${
      active ? "bg-foreground text-background" : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
    }`

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold">My Account</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {session?.user?.name || session?.user?.phone || session?.user?.email}
          </p>
        </div>
        <button
          onClick={() => signOut()}
          className="inline-flex items-center gap-2 rounded-lg border border-border px-4 py-2 text-sm font-medium text-muted-foreground hover:bg-destructive/10 hover:text-destructive self-start"
        >
          <LogOut className="h-4 w-4" /> Sign Out
        </button>
      </motion.div>

      <div className="mt-6 flex gap-2">
        <button onClick={() => setTab("profile")} className={tabClass(tab === "profile")}>
          <User className="h-4 w-4" /> Profile
        </button>
        <button onClick={() => setTab("orders")} className={tabClass(tab === "orders")}>
          <Package className="h-4 w-4" /> Orders
          {orders.length > 0 && (
            <span className="ml-1 rounded-full bg-foreground/10 px-1.5 py-0.5 text-[10px] font-semibold">
              {orders.length}
            </span>
          )}
        </button>
      </div>

      <div className="mt-6">
        {tab === "profile" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="rounded-xl border border-border p-6">
            <h2 className="text-lg font-semibold">Profile</h2>
            <div className="mt-4 grid gap-6 sm:grid-cols-2">
              <div>
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Name</label>
                <p className="mt-1 font-medium">{session?.user?.name || <span className="text-muted-foreground text-sm">Not set</span>}</p>
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Phone</label>
                <p className="mt-1 font-medium">{session?.user?.phone || <span className="text-muted-foreground text-sm">Not set</span>}</p>
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Email</label>
                <p className="mt-1 font-medium">{session?.user?.email || <span className="text-muted-foreground text-sm">Not set</span>}</p>
              </div>
              <div>
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Account Type</label>
                <p className="mt-1 font-medium capitalize">{session?.user?.role || "user"}</p>
              </div>
            </div>
            <div className="mt-6 flex gap-3">
              <Link href="/shop" className="inline-flex items-center gap-1.5 text-sm font-medium hover:underline">
                <Heart className="h-4 w-4" /> Browse Products <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </div>
          </motion.div>
        )}

        {tab === "orders" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            {orders.length === 0 ? (
              <div className="flex flex-col items-center rounded-xl border border-border py-16 text-center">
                <Package className="h-14 w-14 text-muted-foreground/30" />
                <h3 className="mt-4 text-lg font-semibold">No orders yet</h3>
                <p className="mt-1 text-sm text-muted-foreground">Start shopping to see your orders here</p>
                <Link
                  href="/shop"
                  className="mt-6 inline-flex items-center gap-2 rounded-lg bg-foreground px-6 py-2.5 text-sm font-medium text-background hover:opacity-90"
                >
                  Start Shopping <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            ) : (
              <div className="space-y-4">
                {orders.map((order, i) => {
                  const sc = statusConfig[order.status] || statusConfig.pending
                  const isExpanded = expandedOrder === order.id

                  return (
                    <motion.div
                      key={order.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className="rounded-xl border border-border overflow-hidden"
                    >
                      <button
                        onClick={() => setExpandedOrder(isExpanded ? null : order.id)}
                        className="flex w-full items-center justify-between p-4 text-left hover:bg-muted/30 transition-colors"
                      >
                        <div className="flex items-center gap-4">
                          <div className={`rounded-lg p-2 ${sc.color}`}>
                            <sc.icon className="h-4 w-4" />
                          </div>
                          <div>
                            <p className="font-semibold text-sm">#{order.id.slice(0, 12).toUpperCase()}</p>
                            <p className="text-xs text-muted-foreground mt-0.5">
                              {new Date(order.createdAt).toLocaleDateString("en-IN", { year: "numeric", month: "long", day: "numeric" })}
                              {" · "}{order.items.reduce((s, i) => s + i.quantity, 0)} item{order.items.reduce((s, i) => s + i.quantity, 0) !== 1 ? "s" : ""}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium capitalize ${sc.color}`}>
                            {sc.label}
                          </span>
                          <span className="font-bold text-sm">{formatPrice(order.total)}</span>
                          <ArrowRight className={`h-4 w-4 text-muted-foreground transition-transform ${isExpanded ? "rotate-90" : ""}`} />
                        </div>
                      </button>

                      {isExpanded && (
                        <div className="border-t border-border bg-muted/20 p-4 space-y-4">
                          {/* Items */}
                          <div>
                            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-3">Items</p>
                            <div className="space-y-2">
                              {order.items.map((item) => (
                                <div key={item.id} className="flex items-center gap-3 text-sm">
                                  <div className="h-10 w-10 shrink-0 overflow-hidden rounded-lg border border-border bg-muted flex items-center justify-center">
                                    {item.product.image?.startsWith("http") ? (
                                      // eslint-disable-next-line @next/next/no-img-element
                                      <img src={item.product.image} alt={item.product.name} className="h-full w-full object-cover" />
                                    ) : (
                                      <span className="text-lg">{item.product.image || "🛍️"}</span>
                                    )}
                                  </div>
                                  <Link href={`/shop/${item.product.slug}`} className="flex-1 min-w-0 hover:underline">
                                    <p className="truncate font-medium">{item.product.name}</p>
                                    <p className="text-xs text-muted-foreground">Qty: {item.quantity} × {formatPrice(item.price)}</p>
                                  </Link>
                                  <span className="font-medium shrink-0">{formatPrice(item.price * item.quantity)}</span>
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Summary */}
                          <div className="grid gap-4 sm:grid-cols-2 border-t border-border pt-4">
                            {order.address && (
                              <div>
                                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-1 flex items-center gap-1">
                                  <MapPin className="h-3 w-3" /> Delivery Address
                                </p>
                                <p className="text-sm text-muted-foreground">{order.address}</p>
                              </div>
                            )}
                            {order.paymentId && (
                              <div>
                                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-1 flex items-center gap-1">
                                  <Smartphone className="h-3 w-3" /> Payment
                                </p>
                                <p className="text-sm text-muted-foreground capitalize">{order.paymentMethod || "Online"}</p>
                                <p className="text-xs text-muted-foreground font-mono">{order.paymentId.slice(0, 20)}...</p>
                              </div>
                            )}
                            {order.couponCode && (
                              <div>
                                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-1">Coupon Applied</p>
                                <p className="text-sm text-green-600 dark:text-green-400 font-mono">{order.couponCode}</p>
                                {order.couponDiscount && (
                                  <p className="text-xs text-green-600 dark:text-green-400">You saved {formatPrice(order.couponDiscount)}</p>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </motion.div>
                  )
                })}
              </div>
            )}
          </motion.div>
        )}
      </div>
    </div>
  )
}
