"use client"

import { motion } from "framer-motion"
import {
  Package,
  ShoppingBag,
  Users,
  TrendingUp,
  Plus,
  ArrowUpRight,
  BarChart2,
} from "lucide-react"
import Link from "next/link"
import { useState, useEffect } from "react"
import { formatPrice } from "@/lib/utils"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  CartesianGrid,
  BarChart,
  Bar,
} from "recharts"

interface Stats {
  totalRevenue: number
  totalOrders: number
  totalProducts: number
  totalUsers: number
  revenueChart: { date: string; revenue: number }[]
  statusChart: { status: string; count: number }[]
  monthRevenue: number
  weekRevenue: number
  monthOrders: number
  weekOrders: number
}

interface Order {
  id: string
  createdAt: string
  status: string
  total: number
  user?: { name?: string; phone?: string; email?: string }
  items: { quantity: number }[]
}

const PIE_COLORS: Record<string, string> = {
  delivered: "#22c55e",
  shipped: "#3b82f6",
  processing: "#f59e0b",
  pending: "#a1a1aa",
  cancelled: "#ef4444",
}

export default function AdminPage() {
  const [stats, setStats] = useState<Stats | null>(null)
  const [recentOrders, setRecentOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([
      fetch("/api/admin/stats").then((r) => r.json()),
      fetch("/api/admin/orders").then((r) => r.json()),
    ])
      .then(([statsData, ordersData]) => {
        setStats(statsData)
        setRecentOrders(Array.isArray(ordersData) ? ordersData.slice(0, 6) : [])
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }, [])

  const statusColor = (status: string) => {
    const colors: Record<string, string> = {
      delivered: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400",
      shipped: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
      processing: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400",
      pending: "bg-muted text-muted-foreground",
      cancelled: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400",
    }
    return colors[status] || "bg-muted text-muted-foreground"
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-foreground border-t-transparent" />
      </div>
    )
  }

  const statCards = stats
    ? [
        {
          label: "Total Revenue",
          value: formatPrice(stats.totalRevenue),
          sub: `This week: ${formatPrice(stats.weekRevenue)}`,
          icon: TrendingUp,
          color: "text-green-600 bg-green-100 dark:bg-green-900/30",
          href: "/admin/analytics",
        },
        {
          label: "Total Orders",
          value: String(stats.totalOrders),
          sub: `This week: ${stats.weekOrders}`,
          icon: ShoppingBag,
          color: "text-blue-600 bg-blue-100 dark:bg-blue-900/30",
          href: "/admin/orders",
        },
        {
          label: "Products",
          value: String(stats.totalProducts),
          sub: "In catalog",
          icon: Package,
          color: "text-amber-600 bg-amber-100 dark:bg-amber-900/30",
          href: "/admin/products",
        },
        {
          label: "Users",
          value: String(stats.totalUsers),
          sub: "Registered",
          icon: Users,
          color: "text-purple-600 bg-purple-100 dark:bg-purple-900/30",
          href: "/admin/users",
        },
      ]
    : []

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"
      >
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="mt-1 text-sm text-muted-foreground">Welcome back, Admin</p>
        </div>
        <Link
          href="/admin/products/new"
          className="inline-flex items-center gap-2 rounded-lg bg-foreground px-4 py-2 text-sm font-medium text-background hover:opacity-90 self-start"
        >
          <Plus className="h-4 w-4" /> Add Product
        </Link>
      </motion.div>

      {/* Stats Grid */}
      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {statCards.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 }}
          >
            <Link
              href={stat.href}
              className="group flex flex-col rounded-xl border border-border p-5 transition-colors hover:border-foreground/30 hover:shadow-sm"
            >
              <div className="flex items-center justify-between">
                <div className={`rounded-lg p-2.5 ${stat.color}`}>
                  <stat.icon className="h-5 w-5" />
                </div>
                <ArrowUpRight className="h-4 w-4 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
              </div>
              <p className="mt-3 text-2xl font-bold">{stat.value}</p>
              <p className="text-xs font-medium text-muted-foreground">{stat.label}</p>
              <p className="mt-0.5 text-[11px] text-muted-foreground/70">{stat.sub}</p>
            </Link>
          </motion.div>
        ))}
      </div>

      {/* Charts Row */}
      {stats && (
        <div className="mt-8 grid gap-8 lg:grid-cols-3">
          <div className="rounded-xl border border-border p-6 lg:col-span-2">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Revenue Over Time</h2>
              <Link href="/admin/analytics" className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1">
                Full analytics <BarChart2 className="h-3.5 w-3.5" />
              </Link>
            </div>
            {stats.revenueChart.length === 0 ? (
              <p className="py-12 text-center text-sm text-muted-foreground">No revenue data yet</p>
            ) : (
              <div className="mt-4 h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={stats.revenueChart}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis
                      dataKey="date"
                      className="text-xs"
                      tickFormatter={(v) => new Date(v).toLocaleDateString("en-IN", { month: "short", day: "numeric" })}
                    />
                    <YAxis className="text-xs" tickFormatter={(v) => `₹${v}`} />
                    <Tooltip
                      formatter={(v) => [formatPrice(Number(v)), "Revenue"]}
                      labelFormatter={(l) => new Date(l).toLocaleDateString("en-IN", { year: "numeric", month: "short", day: "numeric" })}
                    />
                    <Line type="monotone" dataKey="revenue" stroke="currentColor" className="stroke-foreground" strokeWidth={2} dot={{ r: 3 }} activeDot={{ r: 5 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>

          <div className="rounded-xl border border-border p-6">
            <h2 className="text-lg font-semibold">Orders by Status</h2>
            {stats.statusChart.length === 0 ? (
              <p className="py-12 text-center text-sm text-muted-foreground">No orders yet</p>
            ) : (
              <div className="mt-4 flex flex-col items-center gap-4">
                <div className="h-44 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={stats.statusChart} dataKey="count" nameKey="status" cx="50%" cy="50%" outerRadius={75} innerRadius={35} paddingAngle={3}>
                        {stats.statusChart.map((entry) => (
                          <Cell key={entry.status} fill={PIE_COLORS[entry.status] || "#a1a1aa"} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex flex-wrap justify-center gap-2 text-xs">
                  {stats.statusChart.map((entry) => (
                    <div key={entry.status} className="flex items-center gap-1">
                      <span className="h-2 w-2 rounded-full" style={{ backgroundColor: PIE_COLORS[entry.status] || "#a1a1aa" }} />
                      <span className="capitalize">{entry.status}</span>
                      <span className="text-muted-foreground">({entry.count})</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Bottom Row */}
      <div className="mt-8 grid gap-8 lg:grid-cols-2">
        {/* Recent Orders */}
        <div className="rounded-xl border border-border p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Recent Orders</h2>
            <Link href="/admin/orders" className="text-sm text-muted-foreground hover:text-foreground">View All</Link>
          </div>
          <div className="mt-4 space-y-2">
            {recentOrders.length === 0 && (
              <p className="py-6 text-center text-sm text-muted-foreground">No orders yet</p>
            )}
            {recentOrders.map((order) => (
              <div key={order.id} className="flex items-center justify-between rounded-lg border border-border p-3">
                <div>
                  <p className="text-sm font-medium">#{order.id.slice(0, 8)}</p>
                  <p className="text-xs text-muted-foreground">
                    {order.user?.name || order.user?.phone || "Customer"} ·{" "}
                    {new Date(order.createdAt).toLocaleDateString("en-IN", { month: "short", day: "numeric" })}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`rounded-full px-2 py-0.5 text-[10px] font-medium capitalize ${statusColor(order.status)}`}>
                    {order.status}
                  </span>
                  <span className="text-sm font-medium">{formatPrice(order.total)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Links */}
        <div className="rounded-xl border border-border p-6">
          <h2 className="text-lg font-semibold">Quick Actions</h2>
          <div className="mt-4 grid grid-cols-2 gap-3">
            {[
              { href: "/admin/products/new", label: "Add Product", icon: Package, color: "bg-amber-50 text-amber-700 dark:bg-amber-900/20 dark:text-amber-400" },
              { href: "/admin/orders", label: "View Orders", icon: ShoppingBag, color: "bg-blue-50 text-blue-700 dark:bg-blue-900/20 dark:text-blue-400" },
              { href: "/admin/coupons", label: "Coupons", icon: TrendingUp, color: "bg-green-50 text-green-700 dark:bg-green-900/20 dark:text-green-400" },
              { href: "/admin/settings", label: "Settings", icon: Users, color: "bg-purple-50 text-purple-700 dark:bg-purple-900/20 dark:text-purple-400" },
              { href: "/admin/analytics", label: "Analytics", icon: BarChart2, color: "bg-rose-50 text-rose-700 dark:bg-rose-900/20 dark:text-rose-400" },
              { href: "/admin/categories", label: "Categories", icon: Package, color: "bg-indigo-50 text-indigo-700 dark:bg-indigo-900/20 dark:text-indigo-400" },
            ].map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-2.5 rounded-xl border border-border p-3.5 text-sm font-medium transition-colors hover:shadow-sm ${item.color}`}
              >
                <item.icon className="h-4 w-4 shrink-0" />
                {item.label}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
