"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import {
  Save, Store, Phone, Mail, MapPin, Percent, Truck, Megaphone, Globe, Loader2,
  CreditCard, Eye, EyeOff,
} from "lucide-react"

interface Settings {
  storeName: string; storeTagline: string; storeLogo: string; storePhone: string
  storeEmail: string; storeAddress: string; taxRate: number; freeShippingThreshold: number
  currencyCode: string; bannerText: string; bannerColor: string; bannerActive: boolean
  heroTitle: string; heroSubtitle: string; metaDescription: string
  // payment gateway
  activeGateway: string
  razorpayKeyId: string; razorpayKeySecret: string
  phonePeMerchantId: string; phonePeSaltKey: string; phonePeSaltIndex: string; phonePeMode: string
  // cod
  codEnabled: boolean; codFee: number
}

const defaultSettings: Settings = {
  storeName: "NS Store", storeTagline: "Your Premium Shopping Destination", storeLogo: "",
  storePhone: "", storeEmail: "", storeAddress: "", taxRate: 18, freeShippingThreshold: 500,
  currencyCode: "INR", bannerText: "", bannerColor: "#18181b", bannerActive: false,
  heroTitle: "Discover Premium Shopping Experience",
  heroSubtitle: "Curated collections of premium products. Free shipping on orders above ₹500.",
  metaDescription: "Shop premium products at NS Store.",
  activeGateway: "razorpay",
  razorpayKeyId: "", razorpayKeySecret: "",
  phonePeMerchantId: "", phonePeSaltKey: "", phonePeSaltIndex: "1", phonePeMode: "sandbox",
  codEnabled: false, codFee: 0,
}

export default function AdminSettingsPage() {
  const [settings, setSettings] = useState<Settings>(defaultSettings)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [error, setError] = useState("")
  const [showRzpSecret, setShowRzpSecret] = useState(false)
  const [showPhonePeKey, setShowPhonePeKey] = useState(false)

  useEffect(() => {
    fetch("/api/admin/settings")
      .then((r) => r.json())
      .then((data) => { if (data && !data.error) setSettings({ ...defaultSettings, ...data }); setLoading(false) })
      .catch(() => setLoading(false))
  }, [])

  const update = (key: keyof Settings, value: string | number | boolean) => {
    setSettings((s) => ({ ...s, [key]: value })); setSaved(false)
  }

  const handleSave = async () => {
    setSaving(true); setError("")
    try {
      const res = await fetch("/api/admin/settings", {
        method: "PUT", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings),
      })
      if (!res.ok) throw new Error("Failed to save")
      const data = await res.json()
      setSettings({ ...defaultSettings, ...data })
      setSaved(true); setTimeout(() => setSaved(false), 3000)
    } catch { setError("Failed to save settings") }
    setSaving(false)
  }

  if (loading) {
    return <div className="flex items-center justify-center py-20"><div className="h-8 w-8 animate-spin rounded-full border-2 border-foreground border-t-transparent" /></div>
  }

  const inputCls = "mt-1 w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-foreground"

  const Section = ({ icon: Icon, title, children }: { icon: React.ElementType; title: string; children: React.ReactNode }) => (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="rounded-xl border border-border p-6">
      <div className="flex items-center gap-2 mb-4">
        <Icon className="h-5 w-5 text-muted-foreground" />
        <h2 className="text-lg font-semibold">{title}</h2>
      </div>
      {children}
    </motion.div>
  )

  const Field = ({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) => (
    <div>
      <label className="text-xs font-medium">{label}</label>
      {children}
      {hint && <p className="mt-1 text-[11px] text-muted-foreground">{hint}</p>}
    </div>
  )

  const SecretField = ({
    label, hint, value, onChange, show, onToggle, placeholder,
  }: { label: string; hint?: string; value: string; onChange: (v: string) => void; show: boolean; onToggle: () => void; placeholder?: string }) => (
    <Field label={label} hint={hint}>
      <div className="relative mt-1">
        <input
          type={show ? "text" : "password"}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full rounded-lg border border-border bg-background px-3 py-2.5 pr-10 text-sm outline-none focus:border-foreground font-mono"
          placeholder={placeholder || "Enter value to update"}
        />
        <button type="button" onClick={onToggle} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
          {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
        </button>
      </div>
    </Field>
  )

  const isMasked = (v: string) => v.startsWith("••")

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Store Settings</h1>
          <p className="mt-1 text-sm text-muted-foreground">Configure your store</p>
        </div>
        <button onClick={handleSave} disabled={saving}
          className="inline-flex items-center gap-2 rounded-lg bg-foreground px-5 py-2.5 text-sm font-medium text-background hover:opacity-90 disabled:opacity-50">
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          {saving ? "Saving…" : saved ? "Saved ✓" : "Save Changes"}
        </button>
      </div>

      {error && <div className="mt-4 rounded-lg bg-destructive/10 p-3 text-sm text-destructive">{error}</div>}

      <div className="mt-8 space-y-6">
        {/* Store Identity */}
        <Section icon={Store} title="Store Identity">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Store Name"><input className={inputCls} value={settings.storeName} onChange={(e) => update("storeName", e.target.value)} /></Field>
            <Field label="Currency Code"><input className={inputCls} value={settings.currencyCode} onChange={(e) => update("currencyCode", e.target.value)} placeholder="INR" /></Field>
            <div className="sm:col-span-2"><Field label="Store Tagline"><input className={inputCls} value={settings.storeTagline} onChange={(e) => update("storeTagline", e.target.value)} /></Field></div>
            <div className="sm:col-span-2"><Field label="Logo URL" hint="Paste a URL for your store logo"><input className={inputCls} value={settings.storeLogo} onChange={(e) => update("storeLogo", e.target.value)} placeholder="https://…" /></Field></div>
          </div>
        </Section>

        {/* Contact */}
        <Section icon={Phone} title="Contact Information">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Phone Number">
              <div className="relative mt-1"><Phone className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input className="w-full rounded-lg border border-border bg-background pl-9 pr-3 py-2.5 text-sm outline-none focus:border-foreground" value={settings.storePhone} onChange={(e) => update("storePhone", e.target.value)} placeholder="+91 98765 43210" /></div>
            </Field>
            <Field label="Email Address">
              <div className="relative mt-1"><Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input className="w-full rounded-lg border border-border bg-background pl-9 pr-3 py-2.5 text-sm outline-none focus:border-foreground" value={settings.storeEmail} onChange={(e) => update("storeEmail", e.target.value)} placeholder="hello@store.com" /></div>
            </Field>
            <div className="sm:col-span-2">
              <Field label="Store Address">
                <div className="relative mt-1"><MapPin className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <textarea className="w-full rounded-lg border border-border bg-background pl-9 pr-3 py-2.5 text-sm outline-none focus:border-foreground" rows={2} value={settings.storeAddress} onChange={(e) => update("storeAddress", e.target.value)} /></div>
              </Field>
            </div>
          </div>
        </Section>

        {/* Pricing */}
        <Section icon={Percent} title="Pricing & Shipping">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Tax Rate (%)" hint="Applied to all orders (GST rate)">
              <input type="number" min={0} max={100} step={0.1} className={inputCls} value={settings.taxRate} onChange={(e) => update("taxRate", parseFloat(e.target.value) || 0)} />
            </Field>
            <Field label="Free Shipping Threshold (₹)" hint="Orders above this amount get free shipping">
              <div className="relative mt-1"><Truck className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input type="number" min={0} className="w-full rounded-lg border border-border bg-background pl-9 pr-3 py-2.5 text-sm outline-none focus:border-foreground" value={settings.freeShippingThreshold} onChange={(e) => update("freeShippingThreshold", parseFloat(e.target.value) || 0)} /></div>
            </Field>
          </div>
        </Section>

        {/* ─── Payment Gateway ─────────────────────────────────────────────────── */}
        <Section icon={CreditCard} title="Payment Gateway">
          <div className="space-y-6">
            {/* Gateway selector */}
            <div>
              <label className="text-xs font-medium">Active Payment Gateway</label>
              <p className="mb-2 text-[11px] text-muted-foreground">Choose which gateway(s) customers see at checkout</p>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { value: "razorpay", label: "Razorpay only", icon: "💳", desc: "UPI, Cards, NetBanking, Wallets" },
                  { value: "phonepe", label: "PhonePe only", icon: "📱", desc: "PhonePe UPI & Wallet" },
                  { value: "both", label: "Both", icon: "⚡", desc: "Show both at checkout" },
                ].map((opt) => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => update("activeGateway", opt.value)}
                    className={`flex flex-col items-center rounded-xl border p-4 text-center transition-colors ${
                      settings.activeGateway === opt.value
                        ? "border-foreground bg-foreground/5"
                        : "border-border hover:border-foreground/40"
                    }`}
                  >
                    <span className="text-2xl">{opt.icon}</span>
                    <span className="mt-1.5 text-xs font-semibold">{opt.label}</span>
                    <span className="mt-0.5 text-[10px] text-muted-foreground leading-tight">{opt.desc}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Razorpay credentials */}
            {(settings.activeGateway === "razorpay" || settings.activeGateway === "both") && (
              <div className="rounded-xl border border-border p-5 space-y-4">
                <div className="flex items-center gap-2">
                  <span className="text-lg">💳</span>
                  <div>
                    <p className="font-semibold text-sm">Razorpay Credentials</p>
                    <p className="text-[11px] text-muted-foreground">
                      Get your keys from{" "}
                      <a href="https://dashboard.razorpay.com/app/keys" target="_blank" rel="noopener noreferrer" className="underline hover:text-foreground">
                        dashboard.razorpay.com
                      </a>
                    </p>
                  </div>
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field label="Key ID" hint="Starts with rzp_test_ or rzp_live_">
                    <input className={inputCls + " font-mono"} value={settings.razorpayKeyId} onChange={(e) => update("razorpayKeyId", e.target.value)} placeholder="rzp_test_xxxxxxxxxx" />
                  </Field>
                  <SecretField
                    label="Key Secret" hint={isMasked(settings.razorpayKeySecret) ? "Secret saved — type a new value to update" : ""}
                    value={settings.razorpayKeySecret} onChange={(v) => update("razorpayKeySecret", v)}
                    show={showRzpSecret} onToggle={() => setShowRzpSecret(!showRzpSecret)}
                    placeholder={isMasked(settings.razorpayKeySecret) ? "Leave blank to keep current" : "Enter Razorpay secret key"}
                  />
                </div>
              </div>
            )}

            {/* PhonePe credentials */}
            {(settings.activeGateway === "phonepe" || settings.activeGateway === "both") && (
              <div className="rounded-xl border border-[#5f259f]/30 bg-[#5f259f]/5 dark:bg-[#5f259f]/10 p-5 space-y-4">
                <div className="flex items-center gap-2">
                  <span className="text-lg">📱</span>
                  <div>
                    <p className="font-semibold text-sm text-[#5f259f] dark:text-purple-300">PhonePe Credentials</p>
                    <p className="text-[11px] text-muted-foreground">
                      Get credentials from your PhonePe Business dashboard or{" "}
                      <a href="https://developer.phonepe.com/v1/docs" target="_blank" rel="noopener noreferrer" className="underline hover:text-foreground">
                        PhonePe Developer Docs
                      </a>
                    </p>
                  </div>
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field label="Merchant ID">
                    <input className={inputCls + " font-mono"} value={settings.phonePeMerchantId} onChange={(e) => update("phonePeMerchantId", e.target.value)} placeholder="MERCHANTUAT" />
                  </Field>
                  <SecretField
                    label="Salt Key" hint={isMasked(settings.phonePeSaltKey) ? "Salt key saved — type a new value to update" : ""}
                    value={settings.phonePeSaltKey} onChange={(v) => update("phonePeSaltKey", v)}
                    show={showPhonePeKey} onToggle={() => setShowPhonePeKey(!showPhonePeKey)}
                    placeholder={isMasked(settings.phonePeSaltKey) ? "Leave blank to keep current" : "Enter PhonePe salt key"}
                  />
                  <Field label="Salt Index" hint="Usually 1">
                    <input className={inputCls + " font-mono"} value={settings.phonePeSaltIndex} onChange={(e) => update("phonePeSaltIndex", e.target.value)} placeholder="1" />
                  </Field>
                  <Field label="Mode" hint="Use Sandbox for testing, Production for live payments">
                    <select className={inputCls} value={settings.phonePeMode} onChange={(e) => update("phonePeMode", e.target.value)}>
                      <option value="sandbox">Sandbox (Test)</option>
                      <option value="production">Production (Live)</option>
                    </select>
                  </Field>
                </div>
                <div className="rounded-lg bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 p-3 text-xs text-amber-700 dark:text-amber-400">
                  <strong>Test credentials:</strong> Use Merchant ID <code className="font-mono">PGTESTPAYUAT</code> and Salt Key <code className="font-mono">099eb0cd-02cf-4e2a-8aca-3e6c6aff0399</code> with Sandbox mode for testing.
                </div>
              </div>
            )}

            {/* COD */}
            <div className="rounded-xl border border-green-200 dark:border-green-800 bg-green-50/50 dark:bg-green-900/10 p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-lg">🚚</span>
                  <div>
                    <p className="font-semibold text-sm">Cash on Delivery (COD)</p>
                    <p className="text-[11px] text-muted-foreground">Customer pays cash when order is delivered</p>
                  </div>
                </div>
                <label className="flex items-center gap-2 cursor-pointer">
                  <div
                    onClick={() => update("codEnabled", !settings.codEnabled)}
                    className={`relative h-6 w-11 rounded-full transition-colors cursor-pointer ${settings.codEnabled ? "bg-green-600" : "bg-muted"}`}
                  >
                    <div className={`absolute top-0.5 left-0.5 h-5 w-5 rounded-full bg-white transition-transform shadow-sm ${settings.codEnabled ? "translate-x-5" : ""}`} />
                  </div>
                  <span className="text-sm font-medium">{settings.codEnabled ? "Enabled" : "Disabled"}</span>
                </label>
              </div>
              {settings.codEnabled && (
                <Field label="COD Handling Fee (₹)" hint="Extra charge for COD orders. Set 0 for no extra charge.">
                  <input
                    type="number" min={0} step={1}
                    className={inputCls}
                    value={settings.codFee}
                    onChange={(e) => update("codFee", parseFloat(e.target.value) || 0)}
                    placeholder="0"
                  />
                </Field>
              )}
            </div>
          </div>
        </Section>

        {/* Banner */}
        <Section icon={Megaphone} title="Announcement Banner">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <Field label="Banner Text" hint="Shown at top of site when active">
                <input className={inputCls} value={settings.bannerText} onChange={(e) => update("bannerText", e.target.value)} placeholder="🎉 Free shipping on orders above ₹500!" />
              </Field>
            </div>
            <Field label="Banner Background Color">
              <div className="mt-1 flex gap-2">
                <input type="color" className="h-10 w-16 cursor-pointer rounded-lg border border-border bg-background p-1 outline-none" value={settings.bannerColor} onChange={(e) => update("bannerColor", e.target.value)} />
                <input className="flex-1 rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-foreground" value={settings.bannerColor} onChange={(e) => update("bannerColor", e.target.value)} />
              </div>
            </Field>
            <Field label="Banner Active">
              <div className="mt-2">
                <label className="flex items-center gap-3 cursor-pointer">
                  <div onClick={() => update("bannerActive", !settings.bannerActive)}
                    className={`relative h-6 w-11 rounded-full transition-colors cursor-pointer ${settings.bannerActive ? "bg-foreground" : "bg-muted"}`}>
                    <div className={`absolute top-0.5 left-0.5 h-5 w-5 rounded-full bg-background transition-transform ${settings.bannerActive ? "translate-x-5" : ""}`} />
                  </div>
                  <span className="text-sm">{settings.bannerActive ? "Active" : "Inactive"}</span>
                </label>
              </div>
            </Field>
          </div>
        </Section>

        {/* SEO */}
        <Section icon={Globe} title="SEO & Homepage">
          <div className="grid gap-4">
            <Field label="Hero Title"><input className={inputCls} value={settings.heroTitle} onChange={(e) => update("heroTitle", e.target.value)} /></Field>
            <Field label="Hero Subtitle"><textarea className={inputCls} rows={2} value={settings.heroSubtitle} onChange={(e) => update("heroSubtitle", e.target.value)} /></Field>
            <Field label="Meta Description" hint="Shown in Google search results"><textarea className={inputCls} rows={2} value={settings.metaDescription} onChange={(e) => update("metaDescription", e.target.value)} /></Field>
          </div>
        </Section>
      </div>

      <div className="mt-8 flex justify-end">
        <button onClick={handleSave} disabled={saving}
          className="inline-flex items-center gap-2 rounded-lg bg-foreground px-8 py-3 text-sm font-medium text-background hover:opacity-90 disabled:opacity-50">
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          {saving ? "Saving…" : saved ? "Saved ✓" : "Save Changes"}
        </button>
      </div>
    </div>
  )
}
