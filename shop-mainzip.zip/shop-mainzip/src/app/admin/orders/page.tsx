"use client"

import { motion } from "framer-motion"
import { useState, useEffect } from "react"
import { formatPrice } from "@/lib/utils"
import { Search, Phone, Mail, ChevronDown, CreditCard } from "lucide-react"

interface OrderItem {
  id: string
  quantity: number
  price: number
  product: { name: string; image: string }
}

interface Order {
  id: string
  createdAt: string
  status: string
  total: number
  address: string | null
  paymentId: string | null
  paymentMethod: string | null
  couponCode: string | null
  user: { id: string; name: string | null; phone: string | null; email: string | null }
  items: OrderItem[]
}

const statusColors: Record<string, string> = {
  delivered: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400",
  shipped: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
  processing: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400",
  pending: "bg-muted text-muted-foreground",
  cancelled: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400",
}

const ALL_STATUSES = ["pending", "processing", "shipped", "delivered", "cancelled"]

export default function AdminOrdersPage() {
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [expandedOrder, setExpandedOrder] = useState<string | null>(null)
  const [updatingStatus, setUpdatingStatus] = useState<string | null>(null)

  const fetchOrders = () => {
    fetch("/api/admin/orders")
      .then((r) => r.json())
      .then((data) => { setOrders(Array.isArray(data) ? data : []); setLoading(false) })
      .catch(() => setLoading(false))
  }

  useEffect(() => { fetchOrders() }, [])

  const updateStatus = async (orderId: string, status: string) => {
    setUpdatingStatus(orderId)
    try {
      await fetch("/api/admin/orders", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: orderId, status }),
      })
      fetchOrders()
    } catch {}
    setUpdatingStatus(null)
  }

  const filtered = orders.filter((o) => {
    const q = search.toLowerCase()
    const matchesSearch = !q || o.id.includes(q) || o.user?.name?.toLowerCase().includes(q) || o.user?.phone?.includes(q) || o.user?.email?.toLowerCase().includes(q)
    const matchesStatus = statusFilter === "all" || o.status === statusFilter
    return matchesSearch && matchesStatus
  })

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-foreground border-t-transparent" />
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold">Orders</h1>
          <p className="mt-1 text-sm text-muted-foreground">{filtered.length} of {orders.length} orders</p>
        </div>
      </div>

      <div className="mt-6 flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by order ID, customer..."
            className="w-full rounded-lg border border-border bg-background pl-9 pr-3 py-2.5 text-sm outline-none focus:border-foreground"
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          <button
            onClick={() => setStatusFilter("all")}
            className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-colors ${statusFilter === "all" ? "bg-foreground text-background" : "border border-border hover:bg-accent"}`}
          >
            All
          </button>
          {ALL_STATUSES.map((s) => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`rounded-lg px-3 py-1.5 text-xs font-medium capitalize transition-colors ${statusFilter === s ? "bg-foreground text-background" : "border border-border hover:bg-accent"}`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-6 space-y-3">
        {filtered.length === 0 && (
          <div className="rounded-xl border border-border p-12 text-center text-muted-foreground">
            <p className="text-sm">No orders found</p>
          </div>
        )}
        {filtered.map((order, i) => {
          const isExpanded = expandedOrder === order.id
          return (
            <motion.div
              key={order.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.03 }}
              className="overflow-hidden rounded-xl border border-border"
            >
              <button
                onClick={() => setExpandedOrder(isExpanded ? null : order.id)}
                className="flex w-full flex-col gap-2 p-4 text-left hover:bg-muted/30 transition-colors sm:flex-row sm:items-center sm:gap-4"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-semibold text-sm">#{order.id.slice(0, 10).toUpperCase()}</span>
                    <span className={`rounded-full px-2 py-0.5 text-[10px] font-medium capitalize ${statusColors[order.status] || "bg-muted text-muted-foreground"}`}>
                      {order.status}
                    </span>
                    {order.paymentId && (
                      <span className="flex items-center gap-1 text-[10px] text-green-600 dark:text-green-400">
                        <CreditCard className="h-3 w-3" /> Paid
                      </span>
                    )}
                  </div>
                  <div className="mt-1 flex flex-wrap gap-3 text-xs text-muted-foreground">
                    <span>{new Date(order.createdAt).toLocaleDateString("en-IN", { year: "numeric", month: "short", day: "numeric" })}</span>
                    {order.user?.name && <span>{order.user.name}</span>}
                    {order.user?.phone && <span className="flex items-center gap-1"><Phone className="h-3 w-3" />{order.user.phone}</span>}
                    {order.user?.email && <span className="flex items-center gap-1"><Mail className="h-3 w-3" />{order.user.email}</span>}
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-bold text-sm">{formatPrice(order.total)}</span>
                  <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform ${isExpanded ? "rotate-180" : ""}`} />
                </div>
              </button>

              {isExpanded && (
                <div className="border-t border-border bg-muted/20 p-4 space-y-4">
                  {/* Items */}
                  <div className="space-y-2">
                    {order.items.map((item) => (
                      <div key={item.id} className="flex items-center gap-3 text-sm">
                        <div className="h-9 w-9 shrink-0 rounded-lg border border-border bg-muted flex items-center justify-center overflow-hidden">
                          {item.product.image?.startsWith("http") ? (
                            // eslint-disable-next-line @next/next/no-img-element
                            <img src={item.product.image} alt={item.product.name} className="h-full w-full object-cover" />
                          ) : (
                            <span className="text-base">{item.product.image || "🛍️"}</span>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="truncate font-medium">{item.product.name}</p>
                          <p className="text-xs text-muted-foreground">Qty: {item.quantity} × {formatPrice(item.price)}</p>
                        </div>
                        <span className="font-medium">{formatPrice(item.price * item.quantity)}</span>
                      </div>
                    ))}
                  </div>

                  {/* Details */}
                  <div className="grid gap-3 border-t border-border pt-4 sm:grid-cols-2 text-sm">
                    {order.address && (
                      <div>
                        <p className="text-xs font-semibold uppercase text-muted-foreground mb-1">Address</p>
                        <p className="text-muted-foreground">{order.address}</p>
                      </div>
                    )}
                    {order.paymentId && (
                      <div>
                        <p className="text-xs font-semibold uppercase text-muted-foreground mb-1">Payment</p>
                        <p className="text-muted-foreground capitalize">{order.paymentMethod || "Online"}</p>
                        <p className="text-xs font-mono text-muted-foreground break-all">{order.paymentId}</p>
                      </div>
                    )}
                    {order.couponCode && (
                      <div>
                        <p className="text-xs font-semibold uppercase text-muted-foreground mb-1">Coupon</p>
                        <p className="font-mono text-green-600 dark:text-green-400">{order.couponCode}</p>
                      </div>
                    )}
                  </div>

                  {/* Status Update */}
                  <div className="border-t border-border pt-4">
                    <p className="text-xs font-semibold uppercase text-muted-foreground mb-2">Update Status</p>
                    <div className="flex flex-wrap gap-2">
                      {ALL_STATUSES.map((s) => (
                        <button
                          key={s}
                          onClick={() => updateStatus(order.id, s)}
                          disabled={order.status === s || updatingStatus === order.id}
                          className={`rounded-lg px-3 py-1.5 text-xs font-medium capitalize transition-colors disabled:opacity-50 ${
                            order.status === s
                              ? statusColors[s] || "bg-muted text-muted-foreground"
                              : "border border-border hover:bg-accent"
                          }`}
                        >
                          {updatingStatus === order.id && order.status !== s ? "..." : s}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          )
        })}
      </div>
    </div>
  )
}
