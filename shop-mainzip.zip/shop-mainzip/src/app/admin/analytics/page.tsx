"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { TrendingUp, ShoppingBag, Users, Package, DollarSign, BarChart2 } from "lucide-react"
import { formatPrice } from "@/lib/utils"
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  CartesianGrid, PieChart, Pie, Cell, Legend,
} from "recharts"

interface AnalyticsData {
  summary: {
    totalRevenue: number
    totalOrders: number
    completedOrders: number
    totalProducts: number
    totalUsers: number
    avgOrderValue: number
  }
  dailyRevenue: { date: string; revenue: number; orders: number }[]
  monthlyRevenue: { month: string; revenue: number; orders: number }[]
  topProducts: { id: string; name: string; revenue: number; units: number; category: string }[]
  revenueByCategory: { category: string; revenue: number }[]
  statusBreakdown: { status: string; count: number }[]
  userGrowth: { date: string; count: number }[]
}

const STATUS_COLORS: Record<string, string> = {
  delivered: "#22c55e",
  shipped: "#3b82f6",
  processing: "#f59e0b",
  pending: "#a1a1aa",
  cancelled: "#ef4444",
}

const CHART_COLORS = ["#18181b", "#3b82f6", "#22c55e", "#f59e0b", "#ef4444", "#8b5cf6", "#ec4899"]

export default function AdminAnalyticsPage() {
  const [data, setData] = useState<AnalyticsData | null>(null)
  const [loading, setLoading] = useState(true)
  const [period, setPeriod] = useState<"daily" | "monthly">("daily")

  useEffect(() => {
    fetch("/api/admin/analytics")
      .then((r) => r.json())
      .then((d) => { setData(d); setLoading(false) })
      .catch(() => setLoading(false))
  }, [])

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-foreground border-t-transparent" />
      </div>
    )
  }

  if (!data) {
    return (
      <div className="flex flex-col items-center py-20 text-center">
        <BarChart2 className="h-12 w-12 text-muted-foreground/30" />
        <p className="mt-3 text-sm text-muted-foreground">Failed to load analytics</p>
      </div>
    )
  }

  const summaryCards = [
    { label: "Total Revenue", value: formatPrice(data.summary.totalRevenue), icon: DollarSign, color: "text-green-600 bg-green-100 dark:bg-green-900/30" },
    { label: "Total Orders", value: String(data.summary.totalOrders), icon: ShoppingBag, color: "text-blue-600 bg-blue-100 dark:bg-blue-900/30" },
    { label: "Avg Order Value", value: formatPrice(data.summary.avgOrderValue), icon: TrendingUp, color: "text-purple-600 bg-purple-100 dark:bg-purple-900/30" },
    { label: "Total Users", value: String(data.summary.totalUsers), icon: Users, color: "text-amber-600 bg-amber-100 dark:bg-amber-900/30" },
  ]

  const chartData = period === "daily" ? data.dailyRevenue : data.monthlyRevenue
  const xKey = period === "daily" ? "date" : "month"
  const xFormatter = (v: string) =>
    period === "daily"
      ? new Date(v).toLocaleDateString("en-IN", { month: "short", day: "numeric" })
      : new Date(v + "-01").toLocaleDateString("en-IN", { month: "short", year: "2-digit" })

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl font-bold">Analytics</h1>
        <p className="mt-1 text-sm text-muted-foreground">Store performance overview</p>
      </motion.div>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {summaryCards.map((card, i) => (
          <motion.div
            key={card.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 }}
            className="rounded-xl border border-border p-5"
          >
            <div className={`inline-flex rounded-lg p-2.5 ${card.color}`}>
              <card.icon className="h-5 w-5" />
            </div>
            <p className="mt-3 text-2xl font-bold">{card.value}</p>
            <p className="text-xs text-muted-foreground">{card.label}</p>
          </motion.div>
        ))}
      </div>

      <div className="mt-8 rounded-xl border border-border p-6">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <h2 className="text-lg font-semibold">Revenue Over Time</h2>
          <div className="flex gap-2">
            {(["daily", "monthly"] as const).map((p) => (
              <button
                key={p}
                onClick={() => setPeriod(p)}
                className={`rounded-lg px-3 py-1.5 text-xs font-medium capitalize transition-colors ${
                  period === p ? "bg-foreground text-background" : "border border-border hover:bg-accent"
                }`}
              >
                {p}
              </button>
            ))}
          </div>
        </div>
        {chartData.length === 0 ? (
          <p className="py-12 text-center text-sm text-muted-foreground">No data yet</p>
        ) : (
          <div className="mt-4 h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis dataKey={xKey} className="text-xs" tickFormatter={xFormatter} />
                <YAxis className="text-xs" tickFormatter={(v) => `₹${v}`} />
                <Tooltip
                  formatter={(v, name) => [name === "revenue" ? formatPrice(Number(v)) : v, name === "revenue" ? "Revenue" : "Orders"]}
                  labelFormatter={xFormatter}
                />
                <Line type="monotone" dataKey="revenue" stroke="#18181b" strokeWidth={2} dot={{ r: 3 }} activeDot={{ r: 5 }} name="revenue" />
                <Line type="monotone" dataKey="orders" stroke="#3b82f6" strokeWidth={2} dot={{ r: 3 }} activeDot={{ r: 5 }} name="orders" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-2">
        <div className="rounded-xl border border-border p-6">
          <h2 className="text-lg font-semibold">Revenue by Category</h2>
          {data.revenueByCategory.length === 0 ? (
            <p className="py-12 text-center text-sm text-muted-foreground">No data yet</p>
          ) : (
            <div className="mt-4 h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data.revenueByCategory} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis type="number" className="text-xs" tickFormatter={(v) => `₹${v}`} />
                  <YAxis dataKey="category" type="category" className="text-xs" width={100} />
                  <Tooltip formatter={(v) => [formatPrice(Number(v)), "Revenue"]} />
                  <Bar dataKey="revenue" fill="#18181b" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        <div className="rounded-xl border border-border p-6">
          <h2 className="text-lg font-semibold">Order Status</h2>
          {data.statusBreakdown.length === 0 ? (
            <p className="py-12 text-center text-sm text-muted-foreground">No orders yet</p>
          ) : (
            <div className="mt-4 flex flex-col items-center gap-4">
              <div className="h-52 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={data.statusBreakdown} dataKey="count" nameKey="status" cx="50%" cy="50%" outerRadius={90} innerRadius={45} paddingAngle={3}>
                      {data.statusBreakdown.map((entry) => (
                        <Cell key={entry.status} fill={STATUS_COLORS[entry.status] || "#a1a1aa"} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex flex-wrap justify-center gap-3 text-xs">
                {data.statusBreakdown.map((entry) => (
                  <div key={entry.status} className="flex items-center gap-1.5">
                    <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: STATUS_COLORS[entry.status] || "#a1a1aa" }} />
                    <span className="capitalize">{entry.status}</span>
                    <span className="text-muted-foreground">({entry.count})</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="mt-8 rounded-xl border border-border p-6">
        <h2 className="text-lg font-semibold">Top Products by Revenue</h2>
        {data.topProducts.length === 0 ? (
          <p className="py-12 text-center text-sm text-muted-foreground">No sales data yet</p>
        ) : (
          <div className="mt-4 space-y-3">
            {data.topProducts.map((product, i) => {
              const maxRevenue = data.topProducts[0].revenue
              const pct = maxRevenue > 0 ? (product.revenue / maxRevenue) * 100 : 0
              return (
                <div key={product.id} className="flex items-center gap-3">
                  <span className="w-5 text-right text-xs text-muted-foreground font-medium">{i + 1}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className="truncate text-sm font-medium">{product.name}</span>
                      <span className="shrink-0 text-sm font-semibold">{formatPrice(product.revenue)}</span>
                    </div>
                    <div className="mt-1 flex items-center gap-2">
                      <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
                        <div className="h-full rounded-full bg-foreground transition-all" style={{ width: `${pct}%` }} />
                      </div>
                      <span className="text-xs text-muted-foreground shrink-0">{product.units} units</span>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>

      <div className="mt-8 rounded-xl border border-border p-6">
        <h2 className="text-lg font-semibold">User Growth (Last 30 Days)</h2>
        {data.userGrowth.length === 0 ? (
          <p className="py-12 text-center text-sm text-muted-foreground">No sign-up data yet</p>
        ) : (
          <div className="mt-4 h-48">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.userGrowth}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis dataKey="date" className="text-xs" tickFormatter={(v) => new Date(v).toLocaleDateString("en-IN", { month: "short", day: "numeric" })} />
                <YAxis className="text-xs" allowDecimals={false} />
                <Tooltip labelFormatter={(v) => new Date(v).toLocaleDateString("en-IN", { month: "long", day: "numeric" })} />
                <Bar dataKey="count" fill="#3b82f6" radius={[4, 4, 0, 0]} name="New Users" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>
    </div>
  )
}
