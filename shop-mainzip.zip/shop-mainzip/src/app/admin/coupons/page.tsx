"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Plus, TicketPercent, X, Loader2, ToggleLeft, ToggleRight, Trash2 } from "lucide-react"
import { formatPrice } from "@/lib/utils"

interface Coupon {
  id: string
  code: string
  discount: number
  type: string
  minOrder: number | null
  maxUses: number | null
  usedCount: number
  active: boolean
  expiresAt: string | null
  createdAt: string
}

export default function AdminCouponsPage() {
  const [coupons, setCoupons] = useState<Coupon[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState("")

  const [code, setCode] = useState("")
  const [discount, setDiscount] = useState("")
  const [type, setType] = useState("percent")
  const [minOrder, setMinOrder] = useState("")
  const [maxUses, setMaxUses] = useState("")
  const [expiresAt, setExpiresAt] = useState("")
  const [active, setActive] = useState(true)

  const fetchCoupons = () => {
    fetch("/api/admin/coupons")
      .then((r) => r.json())
      .then((data) => {
        setCoupons(Array.isArray(data) ? data : [])
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }

  useEffect(() => { fetchCoupons() }, [])

  const resetForm = () => {
    setCode(""); setDiscount(""); setType("percent")
    setMinOrder(""); setMaxUses(""); setExpiresAt(""); setActive(true); setError("")
  }

  const handleCreate = async () => {
    if (!code.trim()) { setError("Code is required"); return }
    if (!discount || isNaN(parseFloat(discount))) { setError("Valid discount is required"); return }
    setSaving(true)
    setError("")
    try {
      const res = await fetch("/api/admin/coupons", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code, discount, type, minOrder: minOrder || null, maxUses: maxUses || null, expiresAt: expiresAt || null, active }),
      })
      const data = await res.json()
      if (!res.ok) { setError(data.error || "Failed"); setSaving(false); return }
      setShowForm(false)
      resetForm()
      fetchCoupons()
    } catch {
      setError("Failed to create coupon")
    }
    setSaving(false)
  }

  const toggleActive = async (coupon: Coupon) => {
    try {
      await fetch("/api/admin/coupons", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: coupon.id, active: !coupon.active }),
      })
      fetchCoupons()
    } catch {}
  }

  const handleDelete = async (coupon: Coupon) => {
    if (!confirm(`Delete coupon "${coupon.code}"?`)) return
    try {
      await fetch("/api/admin/coupons", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: coupon.id }),
      })
      fetchCoupons()
    } catch {}
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-foreground border-t-transparent" />
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Coupons</h1>
          <p className="mt-1 text-sm text-muted-foreground">{coupons.length} coupons</p>
        </div>
        <button
          onClick={() => { resetForm(); setShowForm(true) }}
          className="inline-flex items-center gap-2 rounded-lg bg-foreground px-4 py-2 text-sm font-medium text-background hover:opacity-90"
        >
          <Plus className="h-4 w-4" /> Add Coupon
        </button>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mt-8 overflow-hidden rounded-xl border border-border"
      >
        <table className="w-full text-left text-sm">
          <thead className="bg-muted text-muted-foreground">
            <tr>
              <th className="px-4 py-3 font-medium">Code</th>
              <th className="px-4 py-3 font-medium">Discount</th>
              <th className="px-4 py-3 font-medium hidden sm:table-cell">Min Order</th>
              <th className="px-4 py-3 font-medium hidden sm:table-cell">Used / Max</th>
              <th className="px-4 py-3 font-medium hidden md:table-cell">Expires</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {coupons.length === 0 && (
              <tr>
                <td colSpan={7} className="px-4 py-12 text-center text-muted-foreground">
                  <TicketPercent className="mx-auto h-8 w-8 opacity-30" />
                  <p className="mt-2 text-sm">No coupons yet</p>
                </td>
              </tr>
            )}
            {coupons.map((coupon, i) => (
              <motion.tr
                key={coupon.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: i * 0.04 }}
                className="hover:bg-muted/50"
              >
                <td className="px-4 py-3">
                  <span className="rounded-md bg-muted px-2 py-0.5 font-mono text-xs font-semibold">
                    {coupon.code}
                  </span>
                </td>
                <td className="px-4 py-3 font-medium">
                  {coupon.type === "percent" ? `${coupon.discount}%` : formatPrice(coupon.discount)}
                  <span className="ml-1 text-xs text-muted-foreground">OFF</span>
                </td>
                <td className="hidden px-4 py-3 text-muted-foreground sm:table-cell">
                  {coupon.minOrder ? formatPrice(coupon.minOrder) : "—"}
                </td>
                <td className="hidden px-4 py-3 text-muted-foreground sm:table-cell">
                  {coupon.usedCount} / {coupon.maxUses ?? "∞"}
                </td>
                <td className="hidden px-4 py-3 text-muted-foreground md:table-cell">
                  {coupon.expiresAt
                    ? new Date(coupon.expiresAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })
                    : "Never"}
                </td>
                <td className="px-4 py-3">
                  <button onClick={() => toggleActive(coupon)} className="transition-colors">
                    {coupon.active ? (
                      <span className="flex items-center gap-1 text-green-600 dark:text-green-400">
                        <ToggleRight className="h-5 w-5" />
                        <span className="text-xs">Active</span>
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-muted-foreground">
                        <ToggleLeft className="h-5 w-5" />
                        <span className="text-xs">Off</span>
                      </span>
                    )}
                  </button>
                </td>
                <td className="px-4 py-3 text-right">
                  <button
                    onClick={() => handleDelete(coupon)}
                    className="rounded-lg p-2 text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </motion.div>

      <AnimatePresence>
        {showForm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="mx-4 w-full max-w-md rounded-xl border border-border bg-background p-6"
            >
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold">Create Coupon</h2>
                <button onClick={() => setShowForm(false)} className="text-muted-foreground hover:text-foreground"><X className="h-5 w-5" /></button>
              </div>
              <div className="mt-4 space-y-4">
                {error && <div className="rounded-lg bg-destructive/10 p-3 text-sm text-destructive">{error}</div>}
                <div>
                  <label className="text-xs font-medium">Coupon Code *</label>
                  <input value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm font-mono outline-none focus:border-foreground" placeholder="SAVE10" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-medium">Discount *</label>
                    <input type="number" min={0} value={discount} onChange={(e) => setDiscount(e.target.value)} className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-foreground" placeholder="10" />
                  </div>
                  <div>
                    <label className="text-xs font-medium">Type</label>
                    <select value={type} onChange={(e) => setType(e.target.value)} className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-foreground">
                      <option value="percent">Percent (%)</option>
                      <option value="fixed">Fixed (₹)</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-medium">Min Order (₹)</label>
                    <input type="number" min={0} value={minOrder} onChange={(e) => setMinOrder(e.target.value)} className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-foreground" placeholder="Optional" />
                  </div>
                  <div>
                    <label className="text-xs font-medium">Max Uses</label>
                    <input type="number" min={1} value={maxUses} onChange={(e) => setMaxUses(e.target.value)} className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-foreground" placeholder="Unlimited" />
                  </div>
                </div>
                <div>
                  <label className="text-xs font-medium">Expiry Date</label>
                  <input type="datetime-local" value={expiresAt} onChange={(e) => setExpiresAt(e.target.value)} className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-foreground" />
                </div>
                <label className="flex items-center gap-2 text-sm">
                  <input type="checkbox" checked={active} onChange={(e) => setActive(e.target.checked)} className="rounded border-border" />
                  Active immediately
                </label>
              </div>
              <div className="mt-6 flex gap-2">
                <button onClick={handleCreate} disabled={saving} className="flex-1 inline-flex items-center justify-center gap-2 rounded-lg bg-foreground px-4 py-2.5 text-sm font-medium text-background hover:opacity-90 disabled:opacity-50">
                  {saving && <Loader2 className="h-4 w-4 animate-spin" />}
                  {saving ? "Creating..." : "Create Coupon"}
                </button>
                <button onClick={() => setShowForm(false)} className="flex-1 rounded-lg border border-border px-4 py-2.5 text-sm font-medium hover:bg-accent">Cancel</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  )
}
