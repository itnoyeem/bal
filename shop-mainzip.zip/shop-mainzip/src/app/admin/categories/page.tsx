"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Plus, Edit3, Trash2, Tag, Loader2, X } from "lucide-react"

interface Category {
  id: string
  name: string
  slug: string
  image: string
  _count: { products: number }
}

export default function AdminCategoriesPage() {
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editCategory, setEditCategory] = useState<Category | null>(null)
  const [name, setName] = useState("")
  const [image, setImage] = useState("")
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState("")

  const fetchCategories = () => {
    fetch("/api/admin/categories")
      .then((r) => r.json())
      .then((data) => {
        setCategories(Array.isArray(data) ? data : [])
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }

  useEffect(() => { fetchCategories() }, [])

  const openAdd = () => {
    setEditCategory(null)
    setName("")
    setImage("")
    setError("")
    setShowForm(true)
  }

  const openEdit = (cat: Category) => {
    setEditCategory(cat)
    setName(cat.name)
    setImage(cat.image)
    setError("")
    setShowForm(true)
  }

  const handleSave = async () => {
    if (!name.trim()) { setError("Name is required"); return }
    setSaving(true)
    setError("")
    try {
      const res = await fetch("/api/admin/categories", {
        method: editCategory ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editCategory ? { id: editCategory.id, name, image } : { name, image }),
      })
      const data = await res.json()
      if (!res.ok) { setError(data.error || "Failed to save"); setSaving(false); return }
      setShowForm(false)
      fetchCategories()
    } catch {
      setError("Failed to save category")
    }
    setSaving(false)
  }

  const handleDelete = async (cat: Category) => {
    if (!confirm(`Delete "${cat.name}"?`)) return
    try {
      const res = await fetch("/api/admin/categories", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: cat.id }),
      })
      const data = await res.json()
      if (!res.ok) { alert(data.error || "Failed to delete"); return }
      fetchCategories()
    } catch {
      alert("Failed to delete category")
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-foreground border-t-transparent" />
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Categories</h1>
          <p className="mt-1 text-sm text-muted-foreground">{categories.length} categories</p>
        </div>
        <button
          onClick={openAdd}
          className="inline-flex items-center gap-2 rounded-lg bg-foreground px-4 py-2 text-sm font-medium text-background hover:opacity-90"
        >
          <Plus className="h-4 w-4" /> Add Category
        </button>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3"
      >
        {categories.length === 0 && (
          <div className="col-span-full rounded-xl border border-border p-12 text-center text-muted-foreground">
            <Tag className="mx-auto h-10 w-10 opacity-30" />
            <p className="mt-3 text-sm">No categories yet</p>
          </div>
        )}
        {categories.map((cat, i) => (
          <motion.div
            key={cat.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.04 }}
            className="flex items-center justify-between rounded-xl border border-border bg-card p-4"
          >
            <div className="flex items-center gap-3">
              <span className="text-3xl">{cat.image}</span>
              <div>
                <p className="font-medium">{cat.name}</p>
                <p className="text-xs text-muted-foreground">
                  {cat._count.products} product{cat._count.products !== 1 ? "s" : ""}
                </p>
              </div>
            </div>
            <div className="flex gap-1">
              <button
                onClick={() => openEdit(cat)}
                className="rounded-lg p-2 text-muted-foreground hover:bg-accent hover:text-accent-foreground"
              >
                <Edit3 className="h-4 w-4" />
              </button>
              <button
                onClick={() => handleDelete(cat)}
                className="rounded-lg p-2 text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          </motion.div>
        ))}
      </motion.div>

      <AnimatePresence>
        {showForm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="mx-4 w-full max-w-md rounded-xl border border-border bg-background p-6"
            >
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold">
                  {editCategory ? "Edit Category" : "Add Category"}
                </h2>
                <button onClick={() => setShowForm(false)} className="text-muted-foreground hover:text-foreground">
                  <X className="h-5 w-5" />
                </button>
              </div>
              <div className="mt-4 space-y-4">
                {error && (
                  <div className="rounded-lg bg-destructive/10 p-3 text-sm text-destructive">{error}</div>
                )}
                <div>
                  <label className="text-xs font-medium">Category Name *</label>
                  <input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-foreground"
                    placeholder="Electronics"
                    onKeyDown={(e) => e.key === "Enter" && handleSave()}
                  />
                </div>
                <div>
                  <label className="text-xs font-medium">Emoji / Image</label>
                  <input
                    value={image}
                    onChange={(e) => setImage(e.target.value)}
                    className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-foreground"
                    placeholder="📦"
                  />
                  {image && (
                    <div className="mt-2 text-center text-5xl">{image}</div>
                  )}
                </div>
              </div>
              <div className="mt-6 flex gap-2">
                <button
                  onClick={handleSave}
                  disabled={saving}
                  className="flex-1 inline-flex items-center justify-center gap-2 rounded-lg bg-foreground px-4 py-2.5 text-sm font-medium text-background hover:opacity-90 disabled:opacity-50"
                >
                  {saving && <Loader2 className="h-4 w-4 animate-spin" />}
                  {saving ? "Saving..." : editCategory ? "Update" : "Create"}
                </button>
                <button
                  onClick={() => setShowForm(false)}
                  className="flex-1 rounded-lg border border-border px-4 py-2.5 text-sm font-medium hover:bg-accent"
                >
                  Cancel
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  )
}
