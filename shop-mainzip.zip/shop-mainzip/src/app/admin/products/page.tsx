"use client"

import Link from "next/link"
import { motion } from "framer-motion"
import { ArrowLeft, Edit3, Trash2, Plus, Upload, Loader2 } from "lucide-react"
import { useState, useEffect } from "react"
import { formatPrice } from "@/lib/utils"
import AdminGuard from "@/components/AdminGuard"

interface Product {
  id: string
  name: string
  slug: string
  description: string
  buyPrice: number | null
  price: number
  mrp: number | null
  image: string
  rating: number
  reviews: number
  inStock: boolean
  featured: boolean
  category?: { name: string; id: string }
}

interface Category {
  id: string
  name: string
}

export default function AdminProductsPage() {
  return (
    <AdminGuard>
      <AdminProductsContent />
    </AdminGuard>
  )
}

function AdminProductsContent() {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [editName, setEditName] = useState("")
  const [editSellPrice, setEditSellPrice] = useState("")
  const [editBuyPrice, setEditBuyPrice] = useState("")
  const [editMrp, setEditMrp] = useState("")
  const [editDescription, setEditDescription] = useState("")
  const [editImage, setEditImage] = useState("")
  const [editRating, setEditRating] = useState("")
  const [editInStock, setEditInStock] = useState(true)
  const [editFeatured, setEditFeatured] = useState(false)
  const [editCategoryId, setEditCategoryId] = useState("")
  const [categories, setCategories] = useState<Category[]>([])
  const [saving, setSaving] = useState(false)
  const [uploadingEdit, setUploadingEdit] = useState(false)

  const fetchProducts = () => {
    fetch("/api/products")
      .then((r) => r.json())
      .then((data) => {
        setProducts(Array.isArray(data) ? data : [])
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }

  useEffect(() => { fetchProducts() }, [])

  useEffect(() => {
    fetch("/api/categories")
      .then((r) => r.json())
      .then(setCategories)
      .catch(() => {})
  }, [])

  const handleDelete = async (product: Product) => {
    if (!confirm(`Delete "${product.name}"? This cannot be undone.`)) return
    const res = await fetch(`/api/products/${product.slug}`, { method: "DELETE" })
    if (res.ok) {
      setProducts((prev) => prev.filter((p) => p.id !== product.id))
    } else {
      alert("Failed to delete product")
    }
  }

  const handleEdit = (product: Product) => {
    setEditingProduct(product)
    setEditName(product.name)
    setEditSellPrice(String(product.price))
    setEditBuyPrice(product.buyPrice ? String(product.buyPrice) : "")
    setEditMrp(product.mrp ? String(product.mrp) : "")
    setEditDescription(product.description || "")
    setEditImage(product.image || "")
    setEditRating(String(product.rating))
    setEditInStock(product.inStock)
    setEditFeatured(product.featured)
    setEditCategoryId(product.category?.id || "")
  }

  const handleSaveEdit = async () => {
    if (!editingProduct) return
    setSaving(true)
    const res = await fetch(`/api/products/${editingProduct.slug}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: editName,
        description: editDescription,
        price: parseFloat(editSellPrice),
        buyPrice: editBuyPrice ? parseFloat(editBuyPrice) : null,
        mrp: editMrp ? parseFloat(editMrp) : null,
        image: editImage,
        rating: parseFloat(editRating),
        inStock: editInStock,
        featured: editFeatured,
        categoryId: editCategoryId || null,
      }),
    })
    if (res.ok) {
      fetchProducts()
    }
    setEditingProduct(null)
    setSaving(false)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-foreground border-t-transparent" />
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="flex items-center justify-between">
        <div>
          <Link
            href="/admin"
            className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" /> Back to Dashboard
          </Link>
          <h1 className="mt-1 text-3xl font-bold">Products</h1>
        </div>
        <Link
          href="/admin/products/new"
          className="inline-flex items-center gap-2 rounded-lg bg-foreground px-4 py-2 text-sm font-medium text-background hover:opacity-90"
        >
          <Plus className="h-4 w-4" /> Add Product
        </Link>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mt-8 overflow-hidden rounded-xl border border-border"
      >
        <table className="w-full text-left text-sm">
          <thead className="bg-muted text-muted-foreground">
            <tr>
              <th className="px-4 py-3 font-medium">Product</th>
              <th className="px-4 py-3 font-medium">Category</th>
              <th className="px-4 py-3 font-medium">Buy</th>
              <th className="px-4 py-3 font-medium">Sell</th>
              <th className="px-4 py-3 font-medium">MRP</th>
              <th className="px-4 py-3 font-medium">Rating</th>
              <th className="px-4 py-3 font-medium">Stock</th>
              <th className="px-4 py-3 font-medium text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {products.length === 0 && (
              <tr>
                <td colSpan={8} className="px-4 py-12 text-center text-sm text-muted-foreground">
                  No products found
                </td>
              </tr>
            )}
            {products.map((product, i) => {
              const discount = product.mrp && product.mrp > product.price
                ? Math.round(((product.mrp - product.price) / product.mrp) * 100)
                : 0

              return (
                <motion.tr
                  key={product.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.03 }}
                  className="hover:bg-muted/50"
                >
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={product.image || "🛍️"}
                        alt=""
                        className="h-10 w-10 rounded-lg object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).style.display = "none"
                          const parent = (e.target as HTMLImageElement).parentElement
                          if (parent) parent.textContent = "🛍️"
                        }}
                      />
                      <span className="font-medium line-clamp-1">{product.name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-muted-foreground">
                    {product.category?.name || ""}
                  </td>
                  <td className="px-4 py-3 text-muted-foreground">
                    {product.buyPrice ? formatPrice(product.buyPrice) : "-"}
                  </td>
                  <td className="px-4 py-3 font-medium">
                    {formatPrice(product.price)}
                  </td>
                  <td className="px-4 py-3 text-muted-foreground">
                    {product.mrp ? (
                      <span>
                        {formatPrice(product.mrp)}
                        {discount > 0 && (
                          <span className="ml-1 text-xs text-green-600 dark:text-green-400">
                            -{discount}%
                          </span>
                        )}
                      </span>
                    ) : "-"}
                  </td>
                  <td className="px-4 py-3 text-muted-foreground">{product.rating}</td>
                  <td className="px-4 py-3">
                    <span
                      className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                        product.inStock
                          ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                          : "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400"
                      }`}
                    >
                      {product.inStock ? "In Stock" : "Out of Stock"}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex justify-end gap-1">
                      <button
                        onClick={() => handleEdit(product)}
                        className="rounded-lg p-2 text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
                      >
                        <Edit3 className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(product)}
                        className="rounded-lg p-2 text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </motion.tr>
              )
            })}
          </tbody>
        </table>
      </motion.div>

      {editingProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="mx-4 w-full max-w-lg rounded-xl border border-border bg-background p-6">
            <h2 className="text-lg font-semibold">Edit Product</h2>
            <div className="mt-4 max-h-[70vh] space-y-4 overflow-y-auto">
              <div>
                <label className="text-xs font-medium">Name</label>
                <input
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-foreground"
                />
              </div>
              <div>
                <label className="text-xs font-medium">Description</label>
                <textarea
                  value={editDescription}
                  onChange={(e) => setEditDescription(e.target.value)}
                  rows={3}
                  className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-foreground"
                />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-medium">Buy Price (₹)</label>
                  <input
                    type="number"
                    value={editBuyPrice}
                    onChange={(e) => setEditBuyPrice(e.target.value)}
                    className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-foreground"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium">Sell Price (₹)</label>
                  <input
                    type="number"
                    value={editSellPrice}
                    onChange={(e) => setEditSellPrice(e.target.value)}
                    className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-foreground"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium">MRP (₹)</label>
                  <input
                    type="number"
                    value={editMrp}
                    onChange={(e) => setEditMrp(e.target.value)}
                    className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-foreground"
                  />
                </div>
              </div>
              <div>
                <label className="text-xs font-medium">Image</label>
                <div className="mt-1 flex gap-2">
                  <input
                    value={editImage}
                    onChange={(e) => setEditImage(e.target.value)}
                    className="flex-1 rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-foreground"
                    placeholder="Image URL"
                  />
                  <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-lg border border-border px-3 py-2.5 text-sm hover:bg-accent">
                    {uploadingEdit ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Upload className="h-4 w-4" />
                    )}
                    <input
                      type="file"
                      accept="image/jpeg,image/png,image/webp,image/gif"
                      className="hidden"
                      disabled={uploadingEdit}
                      onChange={async (e) => {
                        const file = e.target.files?.[0]
                        if (!file) return
                        setUploadingEdit(true)
                        const fd = new FormData()
                        fd.append("file", file)
                        try {
                          const res = await fetch("/api/upload", { method: "POST", body: fd })
                          const data = await res.json()
                          if (data.url) setEditImage(data.url)
                        } catch {
                          alert("Upload failed")
                        }
                        setUploadingEdit(false)
                        e.target.value = ""
                      }}
                    />
                  </label>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium">Rating (0-5)</label>
                  <input
                    type="number"
                    min="0"
                    max="5"
                    step="0.1"
                    value={editRating}
                    onChange={(e) => setEditRating(e.target.value)}
                    className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-foreground"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium">Category</label>
                  <select
                    value={editCategoryId}
                    onChange={(e) => setEditCategoryId(e.target.value)}
                    className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-foreground"
                  >
                    <option value="">None</option>
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="flex gap-4">
                <label className="flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={editInStock}
                    onChange={(e) => setEditInStock(e.target.checked)}
                    className="rounded border-border"
                  />
                  In Stock
                </label>
                <label className="flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={editFeatured}
                    onChange={(e) => setEditFeatured(e.target.checked)}
                    className="rounded border-border"
                  />
                  Featured
                </label>
              </div>
            </div>
            <div className="mt-6 flex gap-2">
              <button
                onClick={handleSaveEdit}
                disabled={saving}
                className="flex-1 rounded-lg bg-foreground px-4 py-2 text-sm font-medium text-background hover:opacity-90 disabled:opacity-50"
              >
                {saving ? "Saving..." : "Save"}
              </button>
              <button
                onClick={() => setEditingProduct(null)}
                className="flex-1 rounded-lg border border-border px-4 py-2 text-sm font-medium hover:bg-accent"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
