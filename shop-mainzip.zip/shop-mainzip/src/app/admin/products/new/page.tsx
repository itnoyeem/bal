"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { motion } from "framer-motion"
import { ArrowLeft, Plus, Upload, IndianRupee, Star, Package, Tag, Loader2 } from "lucide-react"
import { slugify } from "@/lib/utils"
import AdminGuard from "@/components/AdminGuard"

interface Category {
  id: string
  name: string
  slug: string
}

export default function NewProductPage() {
  return (
    <AdminGuard>
      <NewProductForm />
    </AdminGuard>
  )
}

function NewProductForm() {
  const router = useRouter()
  const [categories, setCategories] = useState<Category[]>([])

  // Basic fields
  const [name, setName] = useState("")
  const [slug, setSlug] = useState("")
  const [description, setDescription] = useState("")
  const [image, setImage] = useState("")

  // Pricing
  const [buyPrice, setBuyPrice] = useState("")
  const [sellPrice, setSellPrice] = useState("")
  const [mrp, setMrp] = useState("")

  // Category
  const [categoryId, setCategoryId] = useState("")

  // Admin controls
  const [rating, setRating] = useState("4.5")
  const [inStock, setInStock] = useState(true)
  const [featured, setFeatured] = useState(false)

  const [error, setError] = useState("")
  const [saving, setSaving] = useState(false)
  const [uploading, setUploading] = useState(false)

  useEffect(() => {
    fetch("/api/categories")
      .then((r) => r.json())
      .then((data) => setCategories(data))
  }, [])

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value
    setName(val)
    if (!slug || slug === slugify(name)) {
      setSlug(slugify(val))
    }
  }

  // Calculated values
  const buyPriceNum = parseFloat(buyPrice) || 0
  const sellPriceNum = parseFloat(sellPrice) || 0
  const mrpNum = parseFloat(mrp) || 0
  const profit = sellPriceNum - buyPriceNum
  const profitMargin = buyPriceNum > 0 ? ((profit / buyPriceNum) * 100) : 0
  const discount = mrpNum > 0 ? Math.round(((mrpNum - sellPriceNum) / mrpNum) * 100) : 0

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)
    setError("")

    const res = await fetch("/api/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name,
        slug,
        description,
        buyPrice: buyPrice || null,
        price: sellPrice,
        mrp: mrp || null,
        image: image || "https://via.placeholder.com/400",
        categoryId: categoryId || null,
        rating,
        inStock,
        featured,
      }),
    })

    if (!res.ok) {
      const data = await res.json()
      setError(data.error || "Failed to create product")
      setSaving(false)
      return
    }

    router.push("/admin/products")
    router.refresh()
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-8 sm:px-6 lg:px-8">
      <Link
        href="/admin/products"
        className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" /> Back to Products
      </Link>

      <motion.h1
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mt-1 text-3xl font-bold"
      >
        Add Product
      </motion.h1>

      <form onSubmit={handleSubmit} className="mt-8 space-y-6">
        {error && (
          <div className="rounded-lg bg-destructive/10 p-3 text-sm text-destructive">{error}</div>
        )}

        {/* Basic Details */}
        <div className="rounded-xl border border-border p-6">
          <div className="flex items-center gap-2">
            <Package className="h-5 w-5 text-muted-foreground" />
            <h2 className="text-lg font-semibold">Basic Details</h2>
          </div>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label className="text-xs font-medium">Product Name *</label>
              <input
                required
                value={name}
                onChange={handleNameChange}
                className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-foreground"
                placeholder="Wireless Headphones"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="text-xs font-medium">Slug</label>
              <input
                value={slug}
                onChange={(e) => setSlug(e.target.value)}
                className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm font-mono text-muted-foreground outline-none focus:border-foreground"
                placeholder="wireless-headphones"
              />
              <p className="mt-1 text-[11px] text-muted-foreground">Auto-generated from name. Edit if needed.</p>
            </div>
            <div className="sm:col-span-2">
              <label className="text-xs font-medium">Description</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={4}
                className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-foreground"
                placeholder="Full product description with features, benefits, specifications..."
              />
            </div>
            <div className="sm:col-span-2">
              <label className="text-xs font-medium">Image</label>
              <div className="mt-1 flex gap-2">
                <input
                  value={image}
                  onChange={(e) => setImage(e.target.value)}
                  className="flex-1 rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-foreground"
                  placeholder="https://images.unsplash.com/photo-..."
                />
                <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-lg border border-border px-3 py-2.5 text-sm hover:bg-accent">
                  {uploading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Upload className="h-4 w-4" />
                  )}
                  <span className="hidden sm:inline">{uploading ? "Uploading..." : "Upload"}</span>
                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/webp,image/gif"
                    className="hidden"
                    disabled={uploading}
                    onChange={async (e) => {
                      const file = e.target.files?.[0]
                      if (!file) return
                      setUploading(true)
                      const fd = new FormData()
                      fd.append("file", file)
                      try {
                        const res = await fetch("/api/upload", { method: "POST", body: fd })
                        const data = await res.json()
                        if (data.url) setImage(data.url)
                      } catch {
                        alert("Upload failed")
                      }
                      setUploading(false)
                      e.target.value = ""
                    }}
                  />
                </label>
              </div>
              {image && (
                <div className="mt-2 overflow-hidden rounded-lg border border-border">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={image}
                    alt="Preview"
                    className="h-32 w-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = "none"
                    }}
                  />
                </div>
              )}
              <p className="mt-1 text-[11px] text-muted-foreground">
                Paste an image URL or click <strong>Upload</strong> to upload from your device
              </p>
            </div>
          </div>
        </div>

        {/* Pricing */}
        <div className="rounded-xl border border-border p-6">
          <div className="flex items-center gap-2">
            <IndianRupee className="h-5 w-5 text-muted-foreground" />
            <h2 className="text-lg font-semibold">Pricing</h2>
          </div>
          <div className="mt-4 grid gap-4 sm:grid-cols-3">
            <div>
              <label className="text-xs font-medium">Buy Price (₹)</label>
              <input
                type="number"
                min={0}
                step="0.01"
                value={buyPrice}
                onChange={(e) => setBuyPrice(e.target.value)}
                className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-foreground"
                placeholder="Cost price"
              />
              <p className="mt-1 text-[11px] text-muted-foreground">Admin&apos;s cost</p>
            </div>
            <div>
              <label className="text-xs font-medium">Sell Price (₹) *</label>
              <input
                required
                type="number"
                min={0}
                step="0.01"
                value={sellPrice}
                onChange={(e) => setSellPrice(e.target.value)}
                className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-foreground"
                placeholder="Selling price"
              />
            </div>
            <div>
              <label className="text-xs font-medium">MRP (₹)</label>
              <input
                type="number"
                min={0}
                step="0.01"
                value={mrp}
                onChange={(e) => setMrp(e.target.value)}
                className="mt-1 w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-foreground"
                placeholder="Max retail price"
              />
            </div>
          </div>

          {/* Pricing Summary */}
          {(buyPriceNum > 0 || sellPriceNum > 0 || mrpNum > 0) && (
            <div className="mt-4 grid grid-cols-3 gap-3 rounded-lg bg-muted/50 p-3 text-sm">
              {sellPriceNum > 0 && buyPriceNum > 0 && (
                <div>
                  <span className="text-xs text-muted-foreground">Profit</span>
                  <p className={`font-semibold ${profit >= 0 ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"}`}>
                    ₹{profit.toFixed(2)}
                    <span className="ml-1 text-xs">({profitMargin.toFixed(0)}%)</span>
                  </p>
                </div>
              )}
              {sellPriceNum > 0 && mrpNum > 0 && mrpNum > sellPriceNum && (
                <div>
                  <span className="text-xs text-muted-foreground">Discount</span>
                  <p className="font-semibold text-green-600 dark:text-green-400">{discount}% OFF</p>
                </div>
              )}
              {sellPriceNum > 0 && mrpNum > 0 && mrpNum < sellPriceNum && (
                <div>
                  <span className="text-xs text-muted-foreground">MRP Warning</span>
                  <p className="font-semibold text-amber-600 dark:text-amber-400">MRP {'<'} Sell Price</p>
                </div>
              )}
              {sellPriceNum > 0 && (
                <div>
                  <span className="text-xs text-muted-foreground">Sell Price</span>
                  <p className="font-semibold">₹{sellPriceNum.toFixed(2)}</p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Category */}
        <div className="rounded-xl border border-border p-6">
          <div className="flex items-center gap-2">
            <Tag className="h-5 w-5 text-muted-foreground" />
            <h2 className="text-lg font-semibold">Category</h2>
          </div>
          <div className="mt-4">
            <select
              value={categoryId}
              onChange={(e) => setCategoryId(e.target.value)}
              className="w-full rounded-lg border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-foreground"
            >
              <option value="">Uncategorized</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Admin Controls */}
        <div className="rounded-xl border border-border p-6">
          <div className="flex items-center gap-2">
            <Star className="h-5 w-5 text-muted-foreground" />
            <h2 className="text-lg font-semibold">Admin Controls</h2>
          </div>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <div>
              <label className="text-xs font-medium">Rating (0 - 5)</label>
              <div className="mt-1 flex items-center gap-3">
                <input
                  type="range"
                  min="0"
                  max="5"
                  step="0.1"
                  value={rating}
                  onChange={(e) => setRating(e.target.value)}
                  className="flex-1 accent-foreground"
                />
                <span className="min-w-[3rem] text-right text-sm font-semibold">{rating}</span>
              </div>
            </div>
            <div className="flex items-end gap-6 pb-1">
              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={inStock}
                  onChange={(e) => setInStock(e.target.checked)}
                  className="rounded border-border"
                />
                In Stock
              </label>
              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={featured}
                  onChange={(e) => setFeatured(e.target.checked)}
                  className="rounded border-border"
                />
                Featured
              </label>
            </div>
          </div>
        </div>

        <div className="flex gap-3">
          <button
            type="submit"
            disabled={saving}
            className="inline-flex items-center gap-2 rounded-lg bg-foreground px-6 py-2.5 text-sm font-medium text-background hover:opacity-90 disabled:opacity-50"
          >
            <Plus className="h-4 w-4" />
            {saving ? "Creating..." : "Create Product"}
          </button>
          <Link
            href="/admin/products"
            className="inline-flex items-center rounded-lg border border-border px-6 py-2.5 text-sm font-medium hover:bg-accent"
          >
            Cancel
          </Link>
        </div>
      </form>
    </div>
  )
}
