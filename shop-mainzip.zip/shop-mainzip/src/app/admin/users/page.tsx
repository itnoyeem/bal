"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Users, Search, Shield, ShieldOff, Phone, Mail } from "lucide-react"
import { formatPrice } from "@/lib/utils"

interface User {
  id: string
  name: string | null
  phone: string | null
  email: string | null
  role: string
  createdAt: string
  _count: { orders: number }
}

export default function AdminUsersPage() {
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState("")
  const [updating, setUpdating] = useState<string | null>(null)

  const fetchUsers = () => {
    fetch("/api/admin/users")
      .then((r) => r.json())
      .then((data) => {
        setUsers(Array.isArray(data) ? data : [])
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }

  useEffect(() => { fetchUsers() }, [])

  const toggleRole = async (user: User) => {
    const newRole = user.role === "admin" ? "user" : "admin"
    if (!confirm(`${newRole === "admin" ? "Promote" : "Demote"} ${user.name || user.phone || user.email} to ${newRole}?`)) return
    setUpdating(user.id)
    try {
      const res = await fetch("/api/admin/users", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: user.id, role: newRole }),
      })
      if (res.ok) fetchUsers()
    } catch {}
    setUpdating(null)
  }

  const filtered = users.filter((u) => {
    const q = search.toLowerCase()
    return (
      !q ||
      u.name?.toLowerCase().includes(q) ||
      u.phone?.includes(q) ||
      u.email?.toLowerCase().includes(q)
    )
  })

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-foreground border-t-transparent" />
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold">Users</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {users.length} total · {users.filter((u) => u.role === "admin").length} admins
          </p>
        </div>
        <div className="relative w-full sm:w-64">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search users..."
            className="w-full rounded-lg border border-border bg-background pl-9 pr-3 py-2.5 text-sm outline-none focus:border-foreground"
          />
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mt-8 overflow-hidden rounded-xl border border-border"
      >
        {/* Mobile cards */}
        <div className="divide-y divide-border sm:hidden">
          {filtered.length === 0 && (
            <div className="p-8 text-center text-sm text-muted-foreground">No users found</div>
          )}
          {filtered.map((user) => (
            <div key={user.id} className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <p className="font-medium truncate">{user.name || "—"}</p>
                    <span className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-medium ${
                      user.role === "admin"
                        ? "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400"
                        : "bg-muted text-muted-foreground"
                    }`}>{user.role}</span>
                  </div>
                  {user.phone && (
                    <div className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
                      <Phone className="h-3 w-3" />{user.phone}
                    </div>
                  )}
                  {user.email && (
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Mail className="h-3 w-3" />{user.email}
                    </div>
                  )}
                  <p className="mt-1 text-xs text-muted-foreground">{user._count.orders} orders · Joined {new Date(user.createdAt).toLocaleDateString("en-IN", { year: "numeric", month: "short" })}</p>
                </div>
                <button
                  onClick={() => toggleRole(user)}
                  disabled={updating === user.id}
                  className={`shrink-0 rounded-lg p-2 text-xs transition-colors ${
                    user.role === "admin"
                      ? "text-purple-600 hover:bg-purple-100 dark:hover:bg-purple-900/30"
                      : "text-muted-foreground hover:bg-accent"
                  }`}
                  title={user.role === "admin" ? "Remove admin" : "Make admin"}
                >
                  {user.role === "admin" ? <ShieldOff className="h-4 w-4" /> : <Shield className="h-4 w-4" />}
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Desktop table */}
        <table className="hidden w-full text-left text-sm sm:table">
          <thead className="bg-muted text-muted-foreground">
            <tr>
              <th className="px-4 py-3 font-medium">User</th>
              <th className="px-4 py-3 font-medium">Contact</th>
              <th className="px-4 py-3 font-medium">Role</th>
              <th className="px-4 py-3 font-medium">Orders</th>
              <th className="px-4 py-3 font-medium">Joined</th>
              <th className="px-4 py-3 font-medium text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {filtered.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-12 text-center text-muted-foreground">
                  <Users className="mx-auto h-8 w-8 opacity-30" />
                  <p className="mt-2 text-sm">No users found</p>
                </td>
              </tr>
            )}
            {filtered.map((user, i) => (
              <motion.tr
                key={user.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.03 }}
                className="hover:bg-muted/50"
              >
                <td className="px-4 py-3 font-medium">{user.name || <span className="text-muted-foreground">—</span>}</td>
                <td className="px-4 py-3 text-muted-foreground text-xs">
                  {user.phone && <div className="flex items-center gap-1"><Phone className="h-3 w-3" />{user.phone}</div>}
                  {user.email && <div className="flex items-center gap-1"><Mail className="h-3 w-3" />{user.email}</div>}
                </td>
                <td className="px-4 py-3">
                  <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium capitalize ${
                    user.role === "admin"
                      ? "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400"
                      : "bg-muted text-muted-foreground"
                  }`}>{user.role}</span>
                </td>
                <td className="px-4 py-3 text-muted-foreground">{user._count.orders}</td>
                <td className="px-4 py-3 text-muted-foreground">
                  {new Date(user.createdAt).toLocaleDateString("en-IN", { year: "numeric", month: "short", day: "numeric" })}
                </td>
                <td className="px-4 py-3 text-right">
                  <button
                    onClick={() => toggleRole(user)}
                    disabled={updating === user.id}
                    className={`rounded-lg p-2 transition-colors ${
                      user.role === "admin"
                        ? "text-purple-600 hover:bg-purple-100 dark:hover:bg-purple-900/30"
                        : "text-muted-foreground hover:bg-accent"
                    } disabled:opacity-50`}
                    title={user.role === "admin" ? "Remove admin" : "Make admin"}
                  >
                    {user.role === "admin" ? <ShieldOff className="h-4 w-4" /> : <Shield className="h-4 w-4" />}
                  </button>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </motion.div>
    </div>
  )
}
