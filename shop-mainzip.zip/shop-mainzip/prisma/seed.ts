import "dotenv/config"
import { PrismaClient } from "@prisma/client"
import bcrypt from "bcryptjs"

const prisma = new PrismaClient()

async function main() {
  // Create admin user
  const adminPassword = await bcrypt.hash("admin123", 12)
  const admin = await prisma.user.upsert({
    where: { email: "admin@nscrop.in" },
    update: {},
    create: {
      name: "Admin",
      email: "admin@nscrop.in",
      password: adminPassword,
      role: "admin",
    },
  })
  console.log("✅ Admin user created:", admin.email)

  // Create demo user
  const userPassword = await bcrypt.hash("user123", 12)
  const user = await prisma.user.upsert({
    where: { email: "user@example.com" },
    update: {},
    create: {
      name: "John Doe",
      email: "user@example.com",
      password: userPassword,
      role: "user",
    },
  })
  console.log("✅ Demo user created:", user.email)

  // Create categories
  const categories = await Promise.all([
    prisma.category.upsert({
      where: { slug: "electronics" },
      update: {},
      create: { name: "Electronics", slug: "electronics", image: "📱" },
    }),
    prisma.category.upsert({
      where: { slug: "fashion" },
      update: {},
      create: { name: "Fashion", slug: "fashion", image: "👕" },
    }),
    prisma.category.upsert({
      where: { slug: "home-living" },
      update: {},
      create: { name: "Home & Living", slug: "home-living", image: "🏠" },
    }),
    prisma.category.upsert({
      where: { slug: "beauty" },
      update: {},
      create: { name: "Beauty", slug: "beauty", image: "💄" },
    }),
    prisma.category.upsert({
      where: { slug: "sports" },
      update: {},
      create: { name: "Sports", slug: "sports", image: "⚽" },
    }),
    prisma.category.upsert({
      where: { slug: "books" },
      update: {},
      create: { name: "Books", slug: "books", image: "📚" },
    }),
  ])
  console.log(`✅ ${categories.length} categories created`)

  // Create products
  const products = [
    { name: "Wireless Noise-Cancelling Headphones", slug: "wireless-noise-cancelling-headphones", description: "Premium wireless headphones with active noise cancellation, 30-hour battery life, and comfortable over-ear design.", buyPrice: 150.00, price: 249.99, mrp: 299.99, image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400", categorySlug: "electronics", rating: 4.8, reviews: 234, featured: true },
    { name: "Minimalist Leather Watch", slug: "minimalist-leather-watch", description: "Elegant minimalist watch with genuine leather strap, sapphire crystal glass, and Japanese quartz movement.", buyPrice: 110.00, price: 189.99, mrp: 229.99, image: "https://images.unsplash.com/photo-1524592094714-0f0654e20314?w=400", categorySlug: "fashion", rating: 4.6, reviews: 156, featured: true },
    { name: "Smart Home Speaker", slug: "smart-home-speaker", description: "Voice-controlled smart speaker with rich 360° sound, smart home hub built-in.", buyPrice: 75.00, price: 129.99, mrp: 159.99, image: "https://images.unsplash.com/photo-1589003077984-894e133dabab?w=400", categorySlug: "electronics", rating: 4.5, reviews: 892, featured: true },
    { name: "Ergonomic Office Chair", slug: "ergonomic-office-chair", description: "Premium ergonomic mesh chair with adjustable lumbar support and 4D armrests.", buyPrice: 280.00, price: 449.99, mrp: 549.99, image: "https://images.unsplash.com/photo-1592078615290-033ee584e267?w=400", categorySlug: "home-living", rating: 4.7, reviews: 321, featured: true },
    { name: "Organic Skincare Set", slug: "organic-skincare-set", description: "Complete organic skincare routine with cleanser, serum, moisturizer, and SPF.", buyPrice: 40.00, price: 79.99, mrp: 99.99, image: "https://images.unsplash.com/photo-1570194065650-d99fb4b38f11?w=400", categorySlug: "beauty", rating: 4.4, reviews: 567, featured: false },
    { name: "Running Shoes Pro", slug: "running-shoes-pro", description: "Professional running shoes with responsive cushioning and carbon-fiber plate.", buyPrice: 100.00, price: 179.99, mrp: 219.99, image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400", categorySlug: "sports", rating: 4.9, reviews: 445, featured: true },
    { name: "Designer Sunglasses", slug: "designer-sunglasses", description: "Handcrafted designer sunglasses with polarized UV400 lenses.", buyPrice: 85.00, price: 159.99, mrp: 199.99, image: "https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=400", categorySlug: "fashion", rating: 4.3, reviews: 189, featured: false },
    { name: "Bestselling Fiction Collection", slug: "bestselling-fiction-collection", description: "A curated set of 5 award-winning fiction novels spanning mystery, romance, and science fiction.", buyPrice: 25.00, price: 49.99, mrp: 69.99, image: "https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400", categorySlug: "books", rating: 4.7, reviews: 1234, featured: true },
    { name: "Premium Bluetooth Earbuds", slug: "premium-bluetooth-earbuds", description: "True wireless earbuds with active noise cancellation, 24-hour battery life, and IPX5 water resistance. Crystal-clear calls with AI noise filtering.", buyPrice: 55.00, price: 129.99, mrp: 169.99, image: "https://images.unsplash.com/photo-1590658268037-6bf12f032f35?w=400", categorySlug: "electronics", rating: 4.6, reviews: 723, featured: true },
  ]

  for (const p of products) {
    const cat = categories.find((c) => c.slug === p.categorySlug)
    await prisma.product.upsert({
      where: { slug: p.slug },
      update: {},
      create: {
        name: p.name,
        slug: p.slug,
        description: p.description,
        buyPrice: p.buyPrice,
        price: p.price,
        mrp: p.mrp,
        image: p.image,
        categoryId: cat!.id,
        rating: p.rating,
        reviews: p.reviews,
        featured: p.featured,
      },
    })
  }
  console.log(`✅ ${products.length} products created`)

  // Create a sample order for the demo user
  const sampleProducts = await prisma.product.findMany({ take: 2 })
  if (sampleProducts.length >= 2) {
    await prisma.order.upsert({
      where: { id: "demo-order-1" },
      update: {},
      create: {
        id: "demo-order-1",
        userId: user.id,
        total: sampleProducts[0].price + sampleProducts[1].price * 2,
        status: "delivered",
        items: {
          create: [
            { productId: sampleProducts[0].id, quantity: 1, price: sampleProducts[0].price },
            { productId: sampleProducts[1].id, quantity: 2, price: sampleProducts[1].price },
          ],
        },
      },
    })
    console.log("✅ Sample order created")
  }
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
