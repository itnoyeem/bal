# Objective
Production upgrade: Razorpay payment, more analytics, admin settings/categories/users/coupons, security fixes, bug fixes, mobile improvements.

# Tasks
### T001: Schema + Package Install [DONE when migration runs]
- Add StoreSettings, Coupon, Newsletter models; add paymentId/paymentMethod/couponCode to Order
- Install razorpay npm package

### T002: Fix existing API bugs
- Slug collision fix in products POST
- Server-side price validation in orders POST

### T003: New payment API routes
- /api/payment/create-order
- /api/payment/verify

### T004: New admin API routes
- /api/admin/settings (GET/PUT)
- /api/admin/categories (GET/POST/PUT/DELETE)
- /api/admin/users (GET/PATCH)
- /api/admin/analytics (GET)
- /api/admin/coupons (GET/POST/PATCH/DELETE)
- /api/newsletter (POST)
- Update /api/admin/stats (top products)

### T005: Admin layout + new pages
- src/app/admin/layout.tsx (sidebar nav)
- /admin/settings page
- /admin/categories page
- /admin/users page
- /admin/coupons page
- /admin/analytics page

### T006: Updated checkout with Razorpay

### T007: Enhanced admin dashboard (more charts)

### T008: Configure workflow & verify
